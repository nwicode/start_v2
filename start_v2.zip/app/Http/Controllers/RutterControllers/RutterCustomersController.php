<?php

namespace App\Http\Controllers\RutterControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RutterCustomersController extends Controller
{
    //
}
