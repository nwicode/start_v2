<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Application_IAP_Description extends Model
{
    use HasFactory;

    protected $table = 'application_i_a_p_descriptions';
    protected $primaryKey = 'id';    

}
