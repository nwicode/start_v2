(function () {
  function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

  function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

  function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

  function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

  function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["application-menu-application-menu-module"], {
    /***/
    "/fUX":
    /*!*********************************************************************************!*\
      !*** ./src/app/constructor/application-menu/application-menu-routing.module.ts ***!
      \*********************************************************************************/

    /*! exports provided: ApplicationMenuRoutingModule */

    /***/
    function fUX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApplicationMenuRoutingModule", function () {
        return ApplicationMenuRoutingModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _application_menu_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./application-menu.component */
      "woOp");

      var routes = [{
        path: '',
        component: _application_menu_component__WEBPACK_IMPORTED_MODULE_2__["ApplicationMenuComponent"]
      }];
      ;

      var ApplicationMenuRoutingModule = function ApplicationMenuRoutingModule() {
        _classCallCheck(this, ApplicationMenuRoutingModule);
      };

      ApplicationMenuRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: ApplicationMenuRoutingModule
      });
      ApplicationMenuRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function ApplicationMenuRoutingModule_Factory(t) {
          return new (t || ApplicationMenuRoutingModule)();
        },
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](ApplicationMenuRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ApplicationMenuRoutingModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "Iq9u":
    /*!*******************************************************************************************!*\
      !*** ./src/app/constructor/ConstructorComponents/gallery-dialog/gallery-dialog.module.ts ***!
      \*******************************************************************************************/

    /*! exports provided: GalleryDialogModule */

    /***/
    function Iq9u(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GalleryDialogModule", function () {
        return GalleryDialogModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _gallery_dialog_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./gallery-dialog.component */
      "XVAz");
      /* harmony import */


      var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/material/tabs */
      "wZkO");
      /* harmony import */


      var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/material/dialog */
      "0IaG");
      /* harmony import */


      var _components_my_images_my_images_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./components/my-images/my-images.component */
      "YR83");
      /* harmony import */


      var _components_dropbox_images_dropbox_images_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./components/dropbox-images/dropbox-images.component */
      "WVSN");
      /* harmony import */


      var _components_adobe_images_adobe_images_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./components/adobe-images/adobe-images.component */
      "KzQS");
      /* harmony import */


      var _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/progress-bar */
      "bv9b");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/form-field */
      "kmnG");
      /* harmony import */


      var _angular_material_select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/material/select */
      "d3UM");
      /* harmony import */


      var _angular_material_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/core */
      "FKr1");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var angular_oauth2_oidc__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! angular-oauth2-oidc */
      "LgUO");
      /* harmony import */


      var _components_local_disk_images_local_disk_images_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ./components/local-disk-images/local-disk-images.component */
      "myXq");
      /* harmony import */


      var _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/material/progress-spinner */
      "Xa2L");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var GalleryDialogModule = function GalleryDialogModule() {
        _classCallCheck(this, GalleryDialogModule);
      };

      GalleryDialogModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: GalleryDialogModule
      });
      GalleryDialogModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function GalleryDialogModule_Factory(t) {
          return new (t || GalleryDialogModule)();
        },
        imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialogModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_3__["MatTabsModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_8__["MatProgressBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormFieldModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MatSelectModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_11__["MatOptionModule"], _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_15__["MatProgressSpinnerModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__["TranslateModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"], angular_oauth2_oidc__WEBPACK_IMPORTED_MODULE_13__["OAuthModule"].forRoot()]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](GalleryDialogModule, {
          declarations: [_gallery_dialog_component__WEBPACK_IMPORTED_MODULE_2__["GalleryDialogComponent"], _components_my_images_my_images_component__WEBPACK_IMPORTED_MODULE_5__["MyImagesComponent"], _components_dropbox_images_dropbox_images_component__WEBPACK_IMPORTED_MODULE_6__["DropboxImagesComponent"], _components_adobe_images_adobe_images_component__WEBPACK_IMPORTED_MODULE_7__["AdobeImagesComponent"], _components_local_disk_images_local_disk_images_component__WEBPACK_IMPORTED_MODULE_14__["LocalDiskImagesComponent"]],
          imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialogModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_3__["MatTabsModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_8__["MatProgressBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormFieldModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MatSelectModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_11__["MatOptionModule"], _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_15__["MatProgressSpinnerModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__["TranslateModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"], angular_oauth2_oidc__WEBPACK_IMPORTED_MODULE_13__["OAuthModule"]],
          exports: [_gallery_dialog_component__WEBPACK_IMPORTED_MODULE_2__["GalleryDialogComponent"], _components_my_images_my_images_component__WEBPACK_IMPORTED_MODULE_5__["MyImagesComponent"], _components_adobe_images_adobe_images_component__WEBPACK_IMPORTED_MODULE_7__["AdobeImagesComponent"], _components_dropbox_images_dropbox_images_component__WEBPACK_IMPORTED_MODULE_6__["DropboxImagesComponent"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GalleryDialogModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            exports: [_gallery_dialog_component__WEBPACK_IMPORTED_MODULE_2__["GalleryDialogComponent"], _components_my_images_my_images_component__WEBPACK_IMPORTED_MODULE_5__["MyImagesComponent"], _components_adobe_images_adobe_images_component__WEBPACK_IMPORTED_MODULE_7__["AdobeImagesComponent"], _components_dropbox_images_dropbox_images_component__WEBPACK_IMPORTED_MODULE_6__["DropboxImagesComponent"]],
            declarations: [_gallery_dialog_component__WEBPACK_IMPORTED_MODULE_2__["GalleryDialogComponent"], _components_my_images_my_images_component__WEBPACK_IMPORTED_MODULE_5__["MyImagesComponent"], _components_dropbox_images_dropbox_images_component__WEBPACK_IMPORTED_MODULE_6__["DropboxImagesComponent"], _components_adobe_images_adobe_images_component__WEBPACK_IMPORTED_MODULE_7__["AdobeImagesComponent"], _components_local_disk_images_local_disk_images_component__WEBPACK_IMPORTED_MODULE_14__["LocalDiskImagesComponent"]],
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__["MatDialogModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_3__["MatTabsModule"], _angular_material_progress_bar__WEBPACK_IMPORTED_MODULE_8__["MatProgressBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__["MatFormFieldModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_10__["MatSelectModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_11__["MatOptionModule"], _angular_material_progress_spinner__WEBPACK_IMPORTED_MODULE_15__["MatProgressSpinnerModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__["TranslateModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"], angular_oauth2_oidc__WEBPACK_IMPORTED_MODULE_13__["OAuthModule"].forRoot()]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "LgUO":
    /*!***************************************************************************************!*\
      !*** ./node_modules/angular-oauth2-oidc/__ivy_ngcc__/fesm2015/angular-oauth2-oidc.js ***!
      \***************************************************************************************/

    /*! exports provided: AUTH_CONFIG, AbstractValidationHandler, AuthConfig, DefaultOAuthInterceptor, JwksValidationHandler, LoginOptions, MemoryStorage, NullValidationHandler, OAuthErrorEvent, OAuthEvent, OAuthInfoEvent, OAuthLogger, OAuthModule, OAuthModuleConfig, OAuthNoopResourceServerErrorHandler, OAuthResourceServerConfig, OAuthResourceServerErrorHandler, OAuthService, OAuthStorage, OAuthSuccessEvent, ReceivedTokens, UrlHelperService, ValidationHandler, ɵa, ɵb, ɵc, ɵd */

    /***/
    function LgUO(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* WEBPACK VAR INJECTION */


      (function (module) {
        /* harmony export (binding) */
        __webpack_require__.d(__webpack_exports__, "AUTH_CONFIG", function () {
          return AUTH_CONFIG;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "AbstractValidationHandler", function () {
          return AbstractValidationHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "AuthConfig", function () {
          return AuthConfig;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "DefaultOAuthInterceptor", function () {
          return DefaultOAuthInterceptor;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "JwksValidationHandler", function () {
          return JwksValidationHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "LoginOptions", function () {
          return LoginOptions;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "MemoryStorage", function () {
          return MemoryStorage;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "NullValidationHandler", function () {
          return NullValidationHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthErrorEvent", function () {
          return OAuthErrorEvent;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthEvent", function () {
          return OAuthEvent;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthInfoEvent", function () {
          return OAuthInfoEvent;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthLogger", function () {
          return OAuthLogger;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthModule", function () {
          return OAuthModule;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthModuleConfig", function () {
          return OAuthModuleConfig;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthNoopResourceServerErrorHandler", function () {
          return OAuthNoopResourceServerErrorHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthResourceServerConfig", function () {
          return OAuthResourceServerConfig;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthResourceServerErrorHandler", function () {
          return OAuthResourceServerErrorHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthService", function () {
          return OAuthService;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthStorage", function () {
          return OAuthStorage;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "OAuthSuccessEvent", function () {
          return OAuthSuccessEvent;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "ReceivedTokens", function () {
          return ReceivedTokens;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "UrlHelperService", function () {
          return UrlHelperService;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "ValidationHandler", function () {
          return ValidationHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "ɵa", function () {
          return HashHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "ɵb", function () {
          return DefaultHashHandler;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "ɵc", function () {
          return createDefaultLogger;
        });
        /* harmony export (binding) */


        __webpack_require__.d(__webpack_exports__, "ɵd", function () {
          return createDefaultStorage;
        });
        /* harmony import */


        var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! @angular/core */
        "fXoL");
        /* harmony import */


        var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! @angular/common */
        "ofXK");
        /* harmony import */


        var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! @angular/common/http */
        "tk/3");
        /* harmony import */


        var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! tslib */
        "mrSG");
        /* harmony import */


        var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
        /*! rxjs */
        "qCKp");
        /* harmony import */


        var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
        /*! rxjs/operators */
        "kU1M");
        /**
         * Additional options that can be passed to tryLogin.
         */


        var LoginOptions = function LoginOptions() {
          _classCallCheck(this, LoginOptions);

          /**
           * Normally, you want to clear your hash fragment after
           * the lib read the token(s) so that they are not displayed
           * anymore in the url. If not, set this to true. For code flow
           * this controls removing query string values.
           */
          this.preventClearHashAfterLogin = false;
        };
        /**
         * Defines the logging interface the OAuthService uses
         * internally. Is compatible with the `console` object,
         * but you can provide your own implementation as well
         * through dependency injection.
         */


        var OAuthLogger = function OAuthLogger() {
          _classCallCheck(this, OAuthLogger);
        };
        /**
         * Defines a simple storage that can be used for
         * storing the tokens at client side.
         * Is compatible to localStorage and sessionStorage,
         * but you can also create your own implementations.
         */


        var OAuthStorage = function OAuthStorage() {
          _classCallCheck(this, OAuthStorage);
        };

        var MemoryStorage = /*#__PURE__*/function () {
          function MemoryStorage() {
            _classCallCheck(this, MemoryStorage);

            this.data = new Map();
          }

          _createClass(MemoryStorage, [{
            key: "getItem",
            value: function getItem(key) {
              return this.data.get(key);
            }
          }, {
            key: "removeItem",
            value: function removeItem(key) {
              this.data["delete"](key);
            }
          }, {
            key: "setItem",
            value: function setItem(key, data) {
              this.data.set(key, data);
            }
          }]);

          return MemoryStorage;
        }();

        MemoryStorage.ɵfac = function MemoryStorage_Factory(t) {
          return new (t || MemoryStorage)();
        };

        MemoryStorage.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
          token: MemoryStorage,
          factory: MemoryStorage.ɵfac
        });
        /*@__PURE__*/

        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MemoryStorage, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
          }], function () {
            return [];
          }, null);
        })();
        /**
         * Represents the received tokens, the received state
         * and the parsed claims from the id-token.
         */


        var ReceivedTokens = function ReceivedTokens() {
          _classCallCheck(this, ReceivedTokens);
        }; // see: https://developer.mozilla.org/en-US/docs/Web/API/WindowBase64/Base64_encoding_and_decoding#The_.22Unicode_Problem.22


        function b64DecodeUnicode(str) {
          var base64 = str.replace(/\-/g, '+').replace(/\_/g, '/');
          return decodeURIComponent(atob(base64).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
          }).join(''));
        }

        function base64UrlEncode(str) {
          var base64 = btoa(str);
          return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
        }
        /**
         * Interface for Handlers that are hooked in to
         * validate tokens.
         */


        var ValidationHandler = function ValidationHandler() {
          _classCallCheck(this, ValidationHandler);
        };
        /**
         * This abstract implementation of ValidationHandler already implements
         * the method validateAtHash. However, to make use of it,
         * you have to override the method calcHash.
         */


        var AbstractValidationHandler = /*#__PURE__*/function () {
          function AbstractValidationHandler() {
            _classCallCheck(this, AbstractValidationHandler);
          }

          _createClass(AbstractValidationHandler, [{
            key: "validateAtHash",
            value:
            /**
             * Validates the at_hash in an id_token against the received access_token.
             */
            function validateAtHash(params) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var hashAlg, tokenHash, leftMostHalf, atHash, claimsAtHash;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        hashAlg = this.inferHashAlgorithm(params.idTokenHeader);
                        _context.next = 3;
                        return this.calcHash(params.accessToken, hashAlg);

                      case 3:
                        tokenHash = _context.sent;
                        // sha256(accessToken, { asString: true });
                        leftMostHalf = tokenHash.substr(0, tokenHash.length / 2);
                        atHash = base64UrlEncode(leftMostHalf);
                        claimsAtHash = params.idTokenClaims['at_hash'].replace(/=/g, '');

                        if (atHash !== claimsAtHash) {
                          console.error('exptected at_hash: ' + atHash);
                          console.error('actual at_hash: ' + claimsAtHash);
                        }

                        return _context.abrupt("return", atHash === claimsAtHash);

                      case 9:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            }
            /**
             * Infers the name of the hash algorithm to use
             * from the alg field of an id_token.
             *
             * @param jwtHeader the id_token's parsed header
             */

          }, {
            key: "inferHashAlgorithm",
            value: function inferHashAlgorithm(jwtHeader) {
              var alg = jwtHeader['alg'];

              if (!alg.match(/^.S[0-9]{3}$/)) {
                throw new Error('Algorithm not supported: ' + alg);
              }

              return 'sha-' + alg.substr(2);
            }
          }]);

          return AbstractValidationHandler;
        }();

        var UrlHelperService = /*#__PURE__*/function () {
          function UrlHelperService() {
            _classCallCheck(this, UrlHelperService);
          }

          _createClass(UrlHelperService, [{
            key: "getHashFragmentParams",
            value: function getHashFragmentParams(customHashFragment) {
              var hash = customHashFragment || window.location.hash;
              hash = decodeURIComponent(hash);

              if (hash.indexOf('#') !== 0) {
                return {};
              }

              var questionMarkPosition = hash.indexOf('?');

              if (questionMarkPosition > -1) {
                hash = hash.substr(questionMarkPosition + 1);
              } else {
                hash = hash.substr(1);
              }

              return this.parseQueryString(hash);
            }
          }, {
            key: "parseQueryString",
            value: function parseQueryString(queryString) {
              var data = {};
              var pairs, pair, separatorIndex, escapedKey, escapedValue, key, value;

              if (queryString === null) {
                return data;
              }

              pairs = queryString.split('&');

              for (var i = 0; i < pairs.length; i++) {
                pair = pairs[i];
                separatorIndex = pair.indexOf('=');

                if (separatorIndex === -1) {
                  escapedKey = pair;
                  escapedValue = null;
                } else {
                  escapedKey = pair.substr(0, separatorIndex);
                  escapedValue = pair.substr(separatorIndex + 1);
                }

                key = decodeURIComponent(escapedKey);
                value = decodeURIComponent(escapedValue);

                if (key.substr(0, 1) === '/') {
                  key = key.substr(1);
                }

                data[key] = value;
              }

              return data;
            }
          }]);

          return UrlHelperService;
        }();

        UrlHelperService.ɵfac = function UrlHelperService_Factory(t) {
          return new (t || UrlHelperService)();
        };

        UrlHelperService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
          token: UrlHelperService,
          factory: UrlHelperService.ɵfac
        });
        /*@__PURE__*/

        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UrlHelperService, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
          }], null, null);
        })();

        var OAuthEvent = function OAuthEvent(type) {
          _classCallCheck(this, OAuthEvent);

          this.type = type;
        };

        var OAuthSuccessEvent = /*#__PURE__*/function (_OAuthEvent) {
          _inherits(OAuthSuccessEvent, _OAuthEvent);

          var _super = _createSuper(OAuthSuccessEvent);

          function OAuthSuccessEvent(type) {
            var _this;

            var info = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            _classCallCheck(this, OAuthSuccessEvent);

            _this = _super.call(this, type);
            _this.info = info;
            return _this;
          }

          return OAuthSuccessEvent;
        }(OAuthEvent);

        var OAuthInfoEvent = /*#__PURE__*/function (_OAuthEvent2) {
          _inherits(OAuthInfoEvent, _OAuthEvent2);

          var _super2 = _createSuper(OAuthInfoEvent);

          function OAuthInfoEvent(type) {
            var _this2;

            var info = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

            _classCallCheck(this, OAuthInfoEvent);

            _this2 = _super2.call(this, type);
            _this2.info = info;
            return _this2;
          }

          return OAuthInfoEvent;
        }(OAuthEvent);

        var OAuthErrorEvent = /*#__PURE__*/function (_OAuthEvent3) {
          _inherits(OAuthErrorEvent, _OAuthEvent3);

          var _super3 = _createSuper(OAuthErrorEvent);

          function OAuthErrorEvent(type, reason) {
            var _this3;

            var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

            _classCallCheck(this, OAuthErrorEvent);

            _this3 = _super3.call(this, type);
            _this3.reason = reason;
            _this3.params = params;
            return _this3;
          }

          return OAuthErrorEvent;
        }(OAuthEvent);

        var AuthConfig = function AuthConfig(json) {
          _classCallCheck(this, AuthConfig);

          /**
           * The client's id as registered with the auth server
           */
          this.clientId = '';
          /**
           * The client's redirectUri as registered with the auth server
           */

          this.redirectUri = '';
          /**
           * An optional second redirectUri where the auth server
           * redirects the user to after logging out.
           */

          this.postLogoutRedirectUri = '';
          /**
           * The auth server's endpoint that allows to log
           * the user in when using implicit flow.
           */

          this.loginUrl = '';
          /**
           * The requested scopes
           */

          this.scope = 'openid profile';
          this.resource = '';
          this.rngUrl = '';
          /**
           * Defines whether to use OpenId Connect during
           * implicit flow.
           */

          this.oidc = true;
          /**
           * Defines whether to request an access token during
           * implicit flow.
           */

          this.requestAccessToken = true;
          this.options = null;
          /**
           * The issuer's uri.
           */

          this.issuer = '';
          /**
           * The logout url.
           */

          this.logoutUrl = '';
          /**
           * Defines whether to clear the hash fragment after logging in.
           */

          this.clearHashAfterLogin = true;
          /**
           * Url of the token endpoint as defined by OpenId Connect and OAuth 2.
           */

          this.tokenEndpoint = null;
          /**
           * Url of the revocation endpoint as defined by OpenId Connect and OAuth 2.
           */

          this.revocationEndpoint = null;
          /**
           * Names of known parameters sent out in the TokenResponse. https://tools.ietf.org/html/rfc6749#section-5.1
           */

          this.customTokenParameters = [];
          /**
           * Url of the userinfo endpoint as defined by OpenId Connect.
           */

          this.userinfoEndpoint = null;
          this.responseType = '';
          /**
           * Defines whether additional debug information should
           * be shown at the console. Note that in certain browsers
           * the verbosity of the console needs to be explicitly set
           * to include Debug level messages.
           */

          this.showDebugInformation = false;
          /**
           * The redirect uri used when doing silent refresh.
           */

          this.silentRefreshRedirectUri = '';
          this.silentRefreshMessagePrefix = '';
          /**
           * Set this to true to display the iframe used for
           * silent refresh for debugging.
           */

          this.silentRefreshShowIFrame = false;
          /**
           * Timeout for silent refresh.
           * @internal
           * depreacted b/c of typo, see silentRefreshTimeout
           */

          this.siletRefreshTimeout = 1000 * 20;
          /**
           * Timeout for silent refresh.
           */

          this.silentRefreshTimeout = 1000 * 20;
          /**
           * Some auth servers don't allow using password flow
           * w/o a client secret while the standards do not
           * demand for it. In this case, you can set a password
           * here. As this password is exposed to the public
           * it does not bring additional security and is therefore
           * as good as using no password.
           */

          this.dummyClientSecret = null;
          /**
           * Defines whether https is required.
           * The default value is remoteOnly which only allows
           * http for localhost, while every other domains need
           * to be used with https.
           */

          this.requireHttps = 'remoteOnly';
          /**
           * Defines whether every url provided by the discovery
           * document has to start with the issuer's url.
           */

          this.strictDiscoveryDocumentValidation = true;
          /**
           * JSON Web Key Set (https://tools.ietf.org/html/rfc7517)
           * with keys used to validate received id_tokens.
           * This is taken out of the disovery document. Can be set manually too.
           */

          this.jwks = null;
          /**
           * Map with additional query parameter that are appended to
           * the request when initializing implicit flow.
           */

          this.customQueryParams = null;
          this.silentRefreshIFrameName = 'angular-oauth-oidc-silent-refresh-iframe';
          /**
           * Defines when the token_timeout event should be raised.
           * If you set this to the default value 0.75, the event
           * is triggered after 75% of the token's life time.
           */

          this.timeoutFactor = 0.75;
          /**
           * If true, the lib will try to check whether the user
           * is still logged in on a regular basis as described
           * in http://openid.net/specs/openid-connect-session-1_0.html#ChangeNotification
           */

          this.sessionChecksEnabled = false;
          /**
           * Interval in msec for checking the session
           * according to http://openid.net/specs/openid-connect-session-1_0.html#ChangeNotification
           */

          this.sessionCheckIntervall = 3 * 1000;
          /**
           * Url for the iframe used for session checks
           */

          this.sessionCheckIFrameUrl = null;
          /**
           * Name of the iframe to use for session checks
           */

          this.sessionCheckIFrameName = 'angular-oauth-oidc-check-session-iframe';
          /**
           * This property has been introduced to disable at_hash checks
           * and is indented for Identity Provider that does not deliver
           * an at_hash EVEN THOUGH its recommended by the OIDC specs.
           * Of course, when disabling these checks the we are bypassing
           * a security check which means we are more vulnerable.
           */

          this.disableAtHashCheck = false;
          /**
           * Defines wether to check the subject of a refreshed token after silent refresh.
           * Normally, it should be the same as before.
           */

          this.skipSubjectCheck = false;
          this.useIdTokenHintForSilentRefresh = false;
          /**
           * Defined whether to skip the validation of the issuer in the discovery document.
           * Normally, the discovey document's url starts with the url of the issuer.
           */

          this.skipIssuerCheck = false;
          /**
           * final state sent to issuer is built as follows:
           * state = nonce + nonceStateSeparator + additional state
           * Default separator is ';' (encoded %3B).
           * In rare cases, this character might be forbidden or inconvenient to use by the issuer so it can be customized.
           */

          this.nonceStateSeparator = ';';
          /**
           * Set this to true to use HTTP BASIC auth for AJAX calls
           */

          this.useHttpBasicAuth = false;
          /**
           * The interceptors waits this time span if there is no token
           */

          this.waitForTokenInMsec = 0;
          /**
           * Code Flow is by defauld used together with PKCI which is also higly recommented.
           * You can disbale it here by setting this flag to true.
           * https://tools.ietf.org/html/rfc7636#section-1.1
           */

          this.disablePKCE = false;
          /**
           * This property allows you to override the method that is used to open the login url,
           * allowing a way for implementations to specify their own method of routing to new
           * urls.
           */

          this.openUri = function (uri) {
            location.href = uri;
          };

          if (json) {
            Object.assign(this, json);
          }
        };
        /**
         * This custom encoder allows charactes like +, % and / to be used in passwords
         */


        var WebHttpUrlEncodingCodec = /*#__PURE__*/function () {
          function WebHttpUrlEncodingCodec() {
            _classCallCheck(this, WebHttpUrlEncodingCodec);
          }

          _createClass(WebHttpUrlEncodingCodec, [{
            key: "encodeKey",
            value: function encodeKey(k) {
              return encodeURIComponent(k);
            }
          }, {
            key: "encodeValue",
            value: function encodeValue(v) {
              return encodeURIComponent(v);
            }
          }, {
            key: "decodeKey",
            value: function decodeKey(k) {
              return decodeURIComponent(k);
            }
          }, {
            key: "decodeValue",
            value: function decodeValue(v) {
              return decodeURIComponent(v);
            }
          }]);

          return WebHttpUrlEncodingCodec;
        }();
        /**
         * [js-sha256]{@link https://github.com/emn178/js-sha256}
         *
         * @version 0.9.0
         * @author Chen, Yi-Cyuan [emn178@gmail.com]
         * @copyright Chen, Yi-Cyuan 2014-2017
         * @license MIT
         */

        /*jslint bitwise: true */


        var ERROR = 'input is invalid type';
        var WINDOW = typeof window === 'object';
        var root = WINDOW ? window : {};

        if (root.JS_SHA256_NO_WINDOW) {
          WINDOW = false;
        }

        var WEB_WORKER = !WINDOW && typeof self === 'object';
        var NODE_JS = !root.JS_SHA256_NO_NODE_JS && typeof process === 'object' && process.versions && process.versions.node;

        if (NODE_JS) {
          root = global;
        } else if (WEB_WORKER) {
          root = self;
        }

        var COMMON_JS = !root.JS_SHA256_NO_COMMON_JS && typeof module === 'object' && module.exports;

        var AMD = typeof define === 'function' && __webpack_require__(
        /*! !webpack amd options */
        "PDX0");

        var ARRAY_BUFFER = !root.JS_SHA256_NO_ARRAY_BUFFER && typeof ArrayBuffer !== 'undefined';
        var HEX_CHARS = '0123456789abcdef'.split('');
        var EXTRA = [-2147483648, 8388608, 32768, 128];
        var SHIFT = [24, 16, 8, 0];
        var K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
        var OUTPUT_TYPES = ['hex', 'array', 'digest', 'arrayBuffer'];
        var blocks = [];

        if (root.JS_SHA256_NO_NODE_JS || !Array.isArray) {
          Array.isArray = function (obj) {
            return Object.prototype.toString.call(obj) === '[object Array]';
          };
        }

        if (ARRAY_BUFFER && (root.JS_SHA256_NO_ARRAY_BUFFER_IS_VIEW || !ArrayBuffer.isView)) {
          ArrayBuffer.isView = function (obj) {
            return typeof obj === 'object' && obj.buffer && obj.buffer.constructor === ArrayBuffer;
          };
        }

        var createOutputMethod = function createOutputMethod(outputType, is224) {
          return function (message) {
            return new Sha256(is224, true).update(message)[outputType]();
          };
        };

        var ɵ0 = createOutputMethod;

        var createMethod = function createMethod(is224) {
          var method = createOutputMethod('hex', is224);

          if (NODE_JS) {
            method = nodeWrap(method, is224);
          }

          method.create = function () {
            return new Sha256(is224);
          };

          method.update = function (message) {
            return method.create().update(message);
          };

          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createOutputMethod(type, is224);
          }

          return method;
        };

        var ɵ1 = createMethod;

        var nodeWrap = function nodeWrap(method, is224) {
          var crypto = eval("require('crypto')");
          var Buffer = eval("require('buffer').Buffer");
          var algorithm = is224 ? 'sha224' : 'sha256';

          var nodeMethod = function nodeMethod(message) {
            if (typeof message === 'string') {
              return crypto.createHash(algorithm).update(message, 'utf8').digest('hex');
            } else {
              if (message === null || message === undefined) {
                throw new Error(ERROR);
              } else if (message.constructor === ArrayBuffer) {
                message = new Uint8Array(message);
              }
            }

            if (Array.isArray(message) || ArrayBuffer.isView(message) || message.constructor === Buffer) {
              return crypto.createHash(algorithm).update(new Buffer(message)).digest('hex');
            } else {
              return method(message);
            }
          };

          return nodeMethod;
        };

        var ɵ2 = nodeWrap;

        var createHmacOutputMethod = function createHmacOutputMethod(outputType, is224) {
          return function (key, message) {
            return new HmacSha256(key, is224, true).update(message)[outputType]();
          };
        };

        var ɵ3 = createHmacOutputMethod;

        var createHmacMethod = function createHmacMethod(is224) {
          var method = createHmacOutputMethod('hex', is224);

          method.create = function (key) {
            return new HmacSha256(key, is224);
          };

          method.update = function (key, message) {
            return method.create(key).update(message);
          };

          for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
            var type = OUTPUT_TYPES[i];
            method[type] = createHmacOutputMethod(type, is224);
          }

          return method;
        };

        var ɵ4 = createHmacMethod;

        function Sha256(is224, sharedMemory) {
          if (sharedMemory) {
            blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            this.blocks = blocks;
          } else {
            this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          }

          if (is224) {
            this.h0 = 0xc1059ed8;
            this.h1 = 0x367cd507;
            this.h2 = 0x3070dd17;
            this.h3 = 0xf70e5939;
            this.h4 = 0xffc00b31;
            this.h5 = 0x68581511;
            this.h6 = 0x64f98fa7;
            this.h7 = 0xbefa4fa4;
          } else {
            // 256
            this.h0 = 0x6a09e667;
            this.h1 = 0xbb67ae85;
            this.h2 = 0x3c6ef372;
            this.h3 = 0xa54ff53a;
            this.h4 = 0x510e527f;
            this.h5 = 0x9b05688c;
            this.h6 = 0x1f83d9ab;
            this.h7 = 0x5be0cd19;
          }

          this.block = this.start = this.bytes = this.hBytes = 0;
          this.finalized = this.hashed = false;
          this.first = true;
          this.is224 = is224;
        }

        Sha256.prototype.update = function (message) {
          if (this.finalized) {
            return;
          }

          var notString,
              type = typeof message;

          if (type !== 'string') {
            if (type === 'object') {
              if (message === null) {
                throw new Error(ERROR);
              } else if (ARRAY_BUFFER && message.constructor === ArrayBuffer) {
                message = new Uint8Array(message);
              } else if (!Array.isArray(message)) {
                if (!ARRAY_BUFFER || !ArrayBuffer.isView(message)) {
                  throw new Error(ERROR);
                }
              }
            } else {
              throw new Error(ERROR);
            }

            notString = true;
          }

          var code,
              index = 0,
              i,
              length = message.length,
              blocks = this.blocks;

          while (index < length) {
            if (this.hashed) {
              this.hashed = false;
              blocks[0] = this.block;
              blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            }

            if (notString) {
              for (i = this.start; index < length && i < 64; ++index) {
                blocks[i >> 2] |= message[index] << SHIFT[i++ & 3];
              }
            } else {
              for (i = this.start; index < length && i < 64; ++index) {
                code = message.charCodeAt(index);

                if (code < 0x80) {
                  blocks[i >> 2] |= code << SHIFT[i++ & 3];
                } else if (code < 0x800) {
                  blocks[i >> 2] |= (0xc0 | code >> 6) << SHIFT[i++ & 3];
                  blocks[i >> 2] |= (0x80 | code & 0x3f) << SHIFT[i++ & 3];
                } else if (code < 0xd800 || code >= 0xe000) {
                  blocks[i >> 2] |= (0xe0 | code >> 12) << SHIFT[i++ & 3];
                  blocks[i >> 2] |= (0x80 | code >> 6 & 0x3f) << SHIFT[i++ & 3];
                  blocks[i >> 2] |= (0x80 | code & 0x3f) << SHIFT[i++ & 3];
                } else {
                  code = 0x10000 + ((code & 0x3ff) << 10 | message.charCodeAt(++index) & 0x3ff);
                  blocks[i >> 2] |= (0xf0 | code >> 18) << SHIFT[i++ & 3];
                  blocks[i >> 2] |= (0x80 | code >> 12 & 0x3f) << SHIFT[i++ & 3];
                  blocks[i >> 2] |= (0x80 | code >> 6 & 0x3f) << SHIFT[i++ & 3];
                  blocks[i >> 2] |= (0x80 | code & 0x3f) << SHIFT[i++ & 3];
                }
              }
            }

            this.lastByteIndex = i;
            this.bytes += i - this.start;

            if (i >= 64) {
              this.block = blocks[16];
              this.start = i - 64;
              this.hash();
              this.hashed = true;
            } else {
              this.start = i;
            }
          }

          if (this.bytes > 4294967295) {
            this.hBytes += this.bytes / 4294967296 << 0;
            this.bytes = this.bytes % 4294967296;
          }

          return this;
        };

        Sha256.prototype.finalize = function () {
          if (this.finalized) {
            return;
          }

          this.finalized = true;
          var blocks = this.blocks,
              i = this.lastByteIndex;
          blocks[16] = this.block;
          blocks[i >> 2] |= EXTRA[i & 3];
          this.block = blocks[16];

          if (i >= 56) {
            if (!this.hashed) {
              this.hash();
            }

            blocks[0] = this.block;
            blocks[16] = blocks[1] = blocks[2] = blocks[3] = blocks[4] = blocks[5] = blocks[6] = blocks[7] = blocks[8] = blocks[9] = blocks[10] = blocks[11] = blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
          }

          blocks[14] = this.hBytes << 3 | this.bytes >>> 29;
          blocks[15] = this.bytes << 3;
          this.hash();
        };

        Sha256.prototype.hash = function () {
          var a = this.h0,
              b = this.h1,
              c = this.h2,
              d = this.h3,
              e = this.h4,
              f = this.h5,
              g = this.h6,
              h = this.h7,
              blocks = this.blocks,
              j,
              s0,
              s1,
              maj,
              t1,
              t2,
              ch,
              ab,
              da,
              cd,
              bc;

          for (j = 16; j < 64; ++j) {
            // rightrotate
            t1 = blocks[j - 15];
            s0 = (t1 >>> 7 | t1 << 25) ^ (t1 >>> 18 | t1 << 14) ^ t1 >>> 3;
            t1 = blocks[j - 2];
            s1 = (t1 >>> 17 | t1 << 15) ^ (t1 >>> 19 | t1 << 13) ^ t1 >>> 10;
            blocks[j] = blocks[j - 16] + s0 + blocks[j - 7] + s1 << 0;
          }

          bc = b & c;

          for (j = 0; j < 64; j += 4) {
            if (this.first) {
              if (this.is224) {
                ab = 300032;
                t1 = blocks[0] - 1413257819;
                h = t1 - 150054599 << 0;
                d = t1 + 24177077 << 0;
              } else {
                ab = 704751109;
                t1 = blocks[0] - 210244248;
                h = t1 - 1521486534 << 0;
                d = t1 + 143694565 << 0;
              }

              this.first = false;
            } else {
              s0 = (a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10);
              s1 = (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7);
              ab = a & b;
              maj = ab ^ a & c ^ bc;
              ch = e & f ^ ~e & g;
              t1 = h + s1 + ch + K[j] + blocks[j];
              t2 = s0 + maj;
              h = d + t1 << 0;
              d = t1 + t2 << 0;
            }

            s0 = (d >>> 2 | d << 30) ^ (d >>> 13 | d << 19) ^ (d >>> 22 | d << 10);
            s1 = (h >>> 6 | h << 26) ^ (h >>> 11 | h << 21) ^ (h >>> 25 | h << 7);
            da = d & a;
            maj = da ^ d & b ^ ab;
            ch = h & e ^ ~h & f;
            t1 = g + s1 + ch + K[j + 1] + blocks[j + 1];
            t2 = s0 + maj;
            g = c + t1 << 0;
            c = t1 + t2 << 0;
            s0 = (c >>> 2 | c << 30) ^ (c >>> 13 | c << 19) ^ (c >>> 22 | c << 10);
            s1 = (g >>> 6 | g << 26) ^ (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7);
            cd = c & d;
            maj = cd ^ c & a ^ da;
            ch = g & h ^ ~g & e;
            t1 = f + s1 + ch + K[j + 2] + blocks[j + 2];
            t2 = s0 + maj;
            f = b + t1 << 0;
            b = t1 + t2 << 0;
            s0 = (b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10);
            s1 = (f >>> 6 | f << 26) ^ (f >>> 11 | f << 21) ^ (f >>> 25 | f << 7);
            bc = b & c;
            maj = bc ^ b & d ^ cd;
            ch = f & g ^ ~f & h;
            t1 = e + s1 + ch + K[j + 3] + blocks[j + 3];
            t2 = s0 + maj;
            e = a + t1 << 0;
            a = t1 + t2 << 0;
          }

          this.h0 = this.h0 + a << 0;
          this.h1 = this.h1 + b << 0;
          this.h2 = this.h2 + c << 0;
          this.h3 = this.h3 + d << 0;
          this.h4 = this.h4 + e << 0;
          this.h5 = this.h5 + f << 0;
          this.h6 = this.h6 + g << 0;
          this.h7 = this.h7 + h << 0;
        };

        Sha256.prototype.hex = function () {
          this.finalize();
          var h0 = this.h0,
              h1 = this.h1,
              h2 = this.h2,
              h3 = this.h3,
              h4 = this.h4,
              h5 = this.h5,
              h6 = this.h6,
              h7 = this.h7;
          var hex = HEX_CHARS[h0 >> 28 & 0x0F] + HEX_CHARS[h0 >> 24 & 0x0F] + HEX_CHARS[h0 >> 20 & 0x0F] + HEX_CHARS[h0 >> 16 & 0x0F] + HEX_CHARS[h0 >> 12 & 0x0F] + HEX_CHARS[h0 >> 8 & 0x0F] + HEX_CHARS[h0 >> 4 & 0x0F] + HEX_CHARS[h0 & 0x0F] + HEX_CHARS[h1 >> 28 & 0x0F] + HEX_CHARS[h1 >> 24 & 0x0F] + HEX_CHARS[h1 >> 20 & 0x0F] + HEX_CHARS[h1 >> 16 & 0x0F] + HEX_CHARS[h1 >> 12 & 0x0F] + HEX_CHARS[h1 >> 8 & 0x0F] + HEX_CHARS[h1 >> 4 & 0x0F] + HEX_CHARS[h1 & 0x0F] + HEX_CHARS[h2 >> 28 & 0x0F] + HEX_CHARS[h2 >> 24 & 0x0F] + HEX_CHARS[h2 >> 20 & 0x0F] + HEX_CHARS[h2 >> 16 & 0x0F] + HEX_CHARS[h2 >> 12 & 0x0F] + HEX_CHARS[h2 >> 8 & 0x0F] + HEX_CHARS[h2 >> 4 & 0x0F] + HEX_CHARS[h2 & 0x0F] + HEX_CHARS[h3 >> 28 & 0x0F] + HEX_CHARS[h3 >> 24 & 0x0F] + HEX_CHARS[h3 >> 20 & 0x0F] + HEX_CHARS[h3 >> 16 & 0x0F] + HEX_CHARS[h3 >> 12 & 0x0F] + HEX_CHARS[h3 >> 8 & 0x0F] + HEX_CHARS[h3 >> 4 & 0x0F] + HEX_CHARS[h3 & 0x0F] + HEX_CHARS[h4 >> 28 & 0x0F] + HEX_CHARS[h4 >> 24 & 0x0F] + HEX_CHARS[h4 >> 20 & 0x0F] + HEX_CHARS[h4 >> 16 & 0x0F] + HEX_CHARS[h4 >> 12 & 0x0F] + HEX_CHARS[h4 >> 8 & 0x0F] + HEX_CHARS[h4 >> 4 & 0x0F] + HEX_CHARS[h4 & 0x0F] + HEX_CHARS[h5 >> 28 & 0x0F] + HEX_CHARS[h5 >> 24 & 0x0F] + HEX_CHARS[h5 >> 20 & 0x0F] + HEX_CHARS[h5 >> 16 & 0x0F] + HEX_CHARS[h5 >> 12 & 0x0F] + HEX_CHARS[h5 >> 8 & 0x0F] + HEX_CHARS[h5 >> 4 & 0x0F] + HEX_CHARS[h5 & 0x0F] + HEX_CHARS[h6 >> 28 & 0x0F] + HEX_CHARS[h6 >> 24 & 0x0F] + HEX_CHARS[h6 >> 20 & 0x0F] + HEX_CHARS[h6 >> 16 & 0x0F] + HEX_CHARS[h6 >> 12 & 0x0F] + HEX_CHARS[h6 >> 8 & 0x0F] + HEX_CHARS[h6 >> 4 & 0x0F] + HEX_CHARS[h6 & 0x0F];

          if (!this.is224) {
            hex += HEX_CHARS[h7 >> 28 & 0x0F] + HEX_CHARS[h7 >> 24 & 0x0F] + HEX_CHARS[h7 >> 20 & 0x0F] + HEX_CHARS[h7 >> 16 & 0x0F] + HEX_CHARS[h7 >> 12 & 0x0F] + HEX_CHARS[h7 >> 8 & 0x0F] + HEX_CHARS[h7 >> 4 & 0x0F] + HEX_CHARS[h7 & 0x0F];
          }

          return hex;
        };

        Sha256.prototype.toString = Sha256.prototype.hex;

        Sha256.prototype.digest = function () {
          this.finalize();
          var h0 = this.h0,
              h1 = this.h1,
              h2 = this.h2,
              h3 = this.h3,
              h4 = this.h4,
              h5 = this.h5,
              h6 = this.h6,
              h7 = this.h7;
          var arr = [h0 >> 24 & 0xFF, h0 >> 16 & 0xFF, h0 >> 8 & 0xFF, h0 & 0xFF, h1 >> 24 & 0xFF, h1 >> 16 & 0xFF, h1 >> 8 & 0xFF, h1 & 0xFF, h2 >> 24 & 0xFF, h2 >> 16 & 0xFF, h2 >> 8 & 0xFF, h2 & 0xFF, h3 >> 24 & 0xFF, h3 >> 16 & 0xFF, h3 >> 8 & 0xFF, h3 & 0xFF, h4 >> 24 & 0xFF, h4 >> 16 & 0xFF, h4 >> 8 & 0xFF, h4 & 0xFF, h5 >> 24 & 0xFF, h5 >> 16 & 0xFF, h5 >> 8 & 0xFF, h5 & 0xFF, h6 >> 24 & 0xFF, h6 >> 16 & 0xFF, h6 >> 8 & 0xFF, h6 & 0xFF];

          if (!this.is224) {
            arr.push(h7 >> 24 & 0xFF, h7 >> 16 & 0xFF, h7 >> 8 & 0xFF, h7 & 0xFF);
          }

          return arr;
        };

        Sha256.prototype.array = Sha256.prototype.digest;

        Sha256.prototype.arrayBuffer = function () {
          this.finalize();
          var buffer = new ArrayBuffer(this.is224 ? 28 : 32);
          var dataView = new DataView(buffer);
          dataView.setUint32(0, this.h0);
          dataView.setUint32(4, this.h1);
          dataView.setUint32(8, this.h2);
          dataView.setUint32(12, this.h3);
          dataView.setUint32(16, this.h4);
          dataView.setUint32(20, this.h5);
          dataView.setUint32(24, this.h6);

          if (!this.is224) {
            dataView.setUint32(28, this.h7);
          }

          return buffer;
        };

        function HmacSha256(key, is224, sharedMemory) {
          var i,
              type = typeof key;

          if (type === 'string') {
            var bytes = [],
                length = key.length,
                index = 0,
                code;

            for (i = 0; i < length; ++i) {
              code = key.charCodeAt(i);

              if (code < 0x80) {
                bytes[index++] = code;
              } else if (code < 0x800) {
                bytes[index++] = 0xc0 | code >> 6;
                bytes[index++] = 0x80 | code & 0x3f;
              } else if (code < 0xd800 || code >= 0xe000) {
                bytes[index++] = 0xe0 | code >> 12;
                bytes[index++] = 0x80 | code >> 6 & 0x3f;
                bytes[index++] = 0x80 | code & 0x3f;
              } else {
                code = 0x10000 + ((code & 0x3ff) << 10 | key.charCodeAt(++i) & 0x3ff);
                bytes[index++] = 0xf0 | code >> 18;
                bytes[index++] = 0x80 | code >> 12 & 0x3f;
                bytes[index++] = 0x80 | code >> 6 & 0x3f;
                bytes[index++] = 0x80 | code & 0x3f;
              }
            }

            key = bytes;
          } else {
            if (type === 'object') {
              if (key === null) {
                throw new Error(ERROR);
              } else if (ARRAY_BUFFER && key.constructor === ArrayBuffer) {
                key = new Uint8Array(key);
              } else if (!Array.isArray(key)) {
                if (!ARRAY_BUFFER || !ArrayBuffer.isView(key)) {
                  throw new Error(ERROR);
                }
              }
            } else {
              throw new Error(ERROR);
            }
          }

          if (key.length > 64) {
            key = new Sha256(is224, true).update(key).array();
          }

          var oKeyPad = [],
              iKeyPad = [];

          for (i = 0; i < 64; ++i) {
            var b = key[i] || 0;
            oKeyPad[i] = 0x5c ^ b;
            iKeyPad[i] = 0x36 ^ b;
          }

          Sha256.call(this, is224, sharedMemory);
          this.update(iKeyPad);
          this.oKeyPad = oKeyPad;
          this.inner = true;
          this.sharedMemory = sharedMemory;
        }

        HmacSha256.prototype = new Sha256();

        HmacSha256.prototype.finalize = function () {
          Sha256.prototype.finalize.call(this);

          if (this.inner) {
            this.inner = false;
            var innerHash = this.array();
            Sha256.call(this, this.is224, this.sharedMemory);
            this.update(this.oKeyPad);
            this.update(innerHash);
            Sha256.prototype.finalize.call(this);
          }
        };

        var exports = createMethod();
        exports.sha256 = exports;
        exports.sha224 = createMethod(true);
        exports.sha256.hmac = createHmacMethod();
        exports.sha224.hmac = createHmacMethod(true);
        /**
         * Abstraction for crypto algorithms
         */

        var HashHandler = function HashHandler() {
          _classCallCheck(this, HashHandler);
        };

        var DefaultHashHandler = /*#__PURE__*/function () {
          function DefaultHashHandler() {
            _classCallCheck(this, DefaultHashHandler);
          }

          _createClass(DefaultHashHandler, [{
            key: "calcHash",
            value: function calcHash(valueToHash, algorithm) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                var hashArray, hashString;
                return regeneratorRuntime.wrap(function _callee2$(_context2) {
                  while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        // const encoder = new TextEncoder();
                        // const hashArray = await window.crypto.subtle.digest(algorithm, data);
                        // const data = encoder.encode(valueToHash);
                        hashArray = exports.array(valueToHash); // const hashString = this.toHashString(hashArray);

                        hashString = this.toHashString2(hashArray);
                        return _context2.abrupt("return", hashString);

                      case 3:
                      case "end":
                        return _context2.stop();
                    }
                  }
                }, _callee2, this);
              }));
            }
          }, {
            key: "toHashString2",
            value: function toHashString2(byteArray) {
              var result = '';

              var _iterator = _createForOfIteratorHelper(byteArray),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var e = _step.value;
                  result += String.fromCharCode(e);
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }

              return result;
            }
          }, {
            key: "toHashString",
            value: function toHashString(buffer) {
              var byteArray = new Uint8Array(buffer);
              var result = '';

              var _iterator2 = _createForOfIteratorHelper(byteArray),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var e = _step2.value;
                  result += String.fromCharCode(e);
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }

              return result;
            }
          }]);

          return DefaultHashHandler;
        }();

        DefaultHashHandler.ɵfac = function DefaultHashHandler_Factory(t) {
          return new (t || DefaultHashHandler)();
        };

        DefaultHashHandler.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
          token: DefaultHashHandler,
          factory: DefaultHashHandler.ɵfac
        });
        /*@__PURE__*/

        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DefaultHashHandler, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
          }], null, null);
        })();
        /**
         * Service for logging in and logging out with
         * OIDC and OAuth2. Supports implicit flow and
         * password flow.
         */


        var OAuthService = /*#__PURE__*/function (_AuthConfig) {
          _inherits(OAuthService, _AuthConfig);

          var _super4 = _createSuper(OAuthService);

          function OAuthService(ngZone, http, storage, tokenValidationHandler, config, urlHelper, logger, crypto, document) {
            var _this4;

            _classCallCheck(this, OAuthService);

            var _a;

            _this4 = _super4.call(this);
            _this4.ngZone = ngZone;
            _this4.http = http;
            _this4.config = config;
            _this4.urlHelper = urlHelper;
            _this4.logger = logger;
            _this4.crypto = crypto;
            /**
             * @internal
             * Deprecated:  use property events instead
             */

            _this4.discoveryDocumentLoaded = false;
            /**
             * The received (passed around) state, when logging
             * in with implicit flow.
             */

            _this4.state = '';
            _this4.eventsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
            _this4.discoveryDocumentLoadedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
            _this4.grantTypesSupported = [];
            _this4.inImplicitFlow = false;
            _this4.saveNoncesInLocalStorage = false;

            _this4.debug('angular-oauth2-oidc v10'); // See https://github.com/manfredsteyer/angular-oauth2-oidc/issues/773 for why this is needed


            _this4.document = document;

            if (!config) {
              config = {};
            }

            _this4.discoveryDocumentLoaded$ = _this4.discoveryDocumentLoadedSubject.asObservable();
            _this4.events = _this4.eventsSubject.asObservable();

            if (tokenValidationHandler) {
              _this4.tokenValidationHandler = tokenValidationHandler;
            }

            if (config) {
              _this4.configure(config);
            }

            try {
              if (storage) {
                _this4.setStorage(storage);
              } else if (typeof sessionStorage !== 'undefined') {
                _this4.setStorage(sessionStorage);
              }
            } catch (e) {
              console.error('No OAuthStorage provided and cannot access default (sessionStorage).' + 'Consider providing a custom OAuthStorage implementation in your module.', e);
            } // in IE, sessionStorage does not always survive a redirect


            if (typeof window !== 'undefined' && typeof window['localStorage'] !== 'undefined') {
              var ua = (_a = window === null || window === void 0 ? void 0 : window.navigator) === null || _a === void 0 ? void 0 : _a.userAgent;
              var msie = (ua === null || ua === void 0 ? void 0 : ua.includes('MSIE ')) || (ua === null || ua === void 0 ? void 0 : ua.includes('Trident'));

              if (msie) {
                _this4.saveNoncesInLocalStorage = true;
              }
            }

            _this4.setupRefreshTimer();

            return _this4;
          }
          /**
           * Use this method to configure the service
           * @param config the configuration
           */


          _createClass(OAuthService, [{
            key: "configure",
            value: function configure(config) {
              // For the sake of downward compatibility with
              // original configuration API
              Object.assign(this, new AuthConfig(), config);
              this.config = Object.assign({}, new AuthConfig(), config);

              if (this.sessionChecksEnabled) {
                this.setupSessionCheck();
              }

              this.configChanged();
            }
          }, {
            key: "configChanged",
            value: function configChanged() {
              this.setupRefreshTimer();
            }
          }, {
            key: "restartSessionChecksIfStillLoggedIn",
            value: function restartSessionChecksIfStillLoggedIn() {
              if (this.hasValidIdToken()) {
                this.initSessionCheck();
              }
            }
          }, {
            key: "restartRefreshTimerIfStillLoggedIn",
            value: function restartRefreshTimerIfStillLoggedIn() {
              this.setupExpirationTimers();
            }
          }, {
            key: "setupSessionCheck",
            value: function setupSessionCheck() {
              var _this5 = this;

              this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e.type === 'token_received';
              })).subscribe(function (e) {
                _this5.initSessionCheck();
              });
            }
            /**
             * Will setup up silent refreshing for when the token is
             * about to expire. When the user is logged out via this.logOut method, the
             * silent refreshing will pause and not refresh the tokens until the user is
             * logged back in via receiving a new token.
             * @param params Additional parameter to pass
             * @param listenTo Setup automatic refresh of a specific token type
             */

          }, {
            key: "setupAutomaticSilentRefresh",
            value: function setupAutomaticSilentRefresh() {
              var _this6 = this;

              var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
              var listenTo = arguments.length > 1 ? arguments[1] : undefined;
              var noPrompt = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
              var shouldRunSilentRefresh = true;
              this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(function (e) {
                if (e.type === 'token_received') {
                  shouldRunSilentRefresh = true;
                } else if (e.type === 'logout') {
                  shouldRunSilentRefresh = false;
                }
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e.type === 'token_expires';
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["debounceTime"])(1000)).subscribe(function (e) {
                var event = e;

                if ((listenTo == null || listenTo === 'any' || event.info === listenTo) && shouldRunSilentRefresh) {
                  // this.silentRefresh(params, noPrompt).catch(_ => {
                  _this6.refreshInternal(params, noPrompt)["catch"](function (_) {
                    _this6.debug('Automatic silent refresh did not work');
                  });
                }
              });
              this.restartRefreshTimerIfStillLoggedIn();
            }
          }, {
            key: "refreshInternal",
            value: function refreshInternal(params, noPrompt) {
              if (!this.useSilentRefresh && this.responseType === 'code') {
                return this.refreshToken();
              } else {
                return this.silentRefresh(params, noPrompt);
              }
            }
            /**
             * Convenience method that first calls `loadDiscoveryDocument(...)` and
             * directly chains using the `then(...)` part of the promise to call
             * the `tryLogin(...)` method.
             *
             * @param options LoginOptions to pass through to `tryLogin(...)`
             */

          }, {
            key: "loadDiscoveryDocumentAndTryLogin",
            value: function loadDiscoveryDocumentAndTryLogin() {
              var _this7 = this;

              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
              return this.loadDiscoveryDocument().then(function (doc) {
                return _this7.tryLogin(options);
              });
            }
            /**
             * Convenience method that first calls `loadDiscoveryDocumentAndTryLogin(...)`
             * and if then chains to `initLoginFlow()`, but only if there is no valid
             * IdToken or no valid AccessToken.
             *
             * @param options LoginOptions to pass through to `tryLogin(...)`
             */

          }, {
            key: "loadDiscoveryDocumentAndLogin",
            value: function loadDiscoveryDocumentAndLogin() {
              var _this8 = this;

              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
              options = options || {};
              return this.loadDiscoveryDocumentAndTryLogin(options).then(function (_) {
                if (!_this8.hasValidIdToken() || !_this8.hasValidAccessToken()) {
                  var state = typeof options.state === 'string' ? options.state : '';

                  _this8.initLoginFlow(state);

                  return false;
                } else {
                  return true;
                }
              });
            }
          }, {
            key: "debug",
            value: function debug() {
              if (this.showDebugInformation) {
                for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                  args[_key] = arguments[_key];
                }

                this.logger.debug.apply(this.logger, args);
              }
            }
          }, {
            key: "validateUrlFromDiscoveryDocument",
            value: function validateUrlFromDiscoveryDocument(url) {
              var errors = [];
              var httpsCheck = this.validateUrlForHttps(url);
              var issuerCheck = this.validateUrlAgainstIssuer(url);

              if (!httpsCheck) {
                errors.push('https for all urls required. Also for urls received by discovery.');
              }

              if (!issuerCheck) {
                errors.push('Every url in discovery document has to start with the issuer url.' + 'Also see property strictDiscoveryDocumentValidation.');
              }

              return errors;
            }
          }, {
            key: "validateUrlForHttps",
            value: function validateUrlForHttps(url) {
              if (!url) {
                return true;
              }

              var lcUrl = url.toLowerCase();

              if (this.requireHttps === false) {
                return true;
              }

              if ((lcUrl.match(/^http:\/\/localhost($|[:\/])/) || lcUrl.match(/^http:\/\/localhost($|[:\/])/)) && this.requireHttps === 'remoteOnly') {
                return true;
              }

              return lcUrl.startsWith('https://');
            }
          }, {
            key: "assertUrlNotNullAndCorrectProtocol",
            value: function assertUrlNotNullAndCorrectProtocol(url, description) {
              if (!url) {
                throw new Error("'".concat(description, "' should not be null"));
              }

              if (!this.validateUrlForHttps(url)) {
                throw new Error("'".concat(description, "' must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS)."));
              }
            }
          }, {
            key: "validateUrlAgainstIssuer",
            value: function validateUrlAgainstIssuer(url) {
              if (!this.strictDiscoveryDocumentValidation) {
                return true;
              }

              if (!url) {
                return true;
              }

              return url.toLowerCase().startsWith(this.issuer.toLowerCase());
            }
          }, {
            key: "setupRefreshTimer",
            value: function setupRefreshTimer() {
              var _this9 = this;

              if (typeof window === 'undefined') {
                this.debug('timer not supported on this plattform');
                return;
              }

              if (this.hasValidIdToken() || this.hasValidAccessToken()) {
                this.clearAccessTokenTimer();
                this.clearIdTokenTimer();
                this.setupExpirationTimers();
              }

              if (this.tokenReceivedSubscription) this.tokenReceivedSubscription.unsubscribe();
              this.tokenReceivedSubscription = this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e.type === 'token_received';
              })).subscribe(function (_) {
                _this9.clearAccessTokenTimer();

                _this9.clearIdTokenTimer();

                _this9.setupExpirationTimers();
              });
            }
          }, {
            key: "setupExpirationTimers",
            value: function setupExpirationTimers() {
              if (this.hasValidAccessToken()) {
                this.setupAccessTokenTimer();
              }

              if (this.hasValidIdToken()) {
                this.setupIdTokenTimer();
              }
            }
          }, {
            key: "setupAccessTokenTimer",
            value: function setupAccessTokenTimer() {
              var _this10 = this;

              var expiration = this.getAccessTokenExpiration();
              var storedAt = this.getAccessTokenStoredAt();
              var timeout = this.calcTimeout(storedAt, expiration);
              this.ngZone.runOutsideAngular(function () {
                _this10.accessTokenTimeoutSubscription = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new OAuthInfoEvent('token_expires', 'access_token')).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["delay"])(timeout)).subscribe(function (e) {
                  _this10.ngZone.run(function () {
                    _this10.eventsSubject.next(e);
                  });
                });
              });
            }
          }, {
            key: "setupIdTokenTimer",
            value: function setupIdTokenTimer() {
              var _this11 = this;

              var expiration = this.getIdTokenExpiration();
              var storedAt = this.getIdTokenStoredAt();
              var timeout = this.calcTimeout(storedAt, expiration);
              this.ngZone.runOutsideAngular(function () {
                _this11.idTokenTimeoutSubscription = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new OAuthInfoEvent('token_expires', 'id_token')).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["delay"])(timeout)).subscribe(function (e) {
                  _this11.ngZone.run(function () {
                    _this11.eventsSubject.next(e);
                  });
                });
              });
            }
            /**
             * Stops timers for automatic refresh.
             * To restart it, call setupAutomaticSilentRefresh again.
             */

          }, {
            key: "stopAutomaticRefresh",
            value: function stopAutomaticRefresh() {
              this.clearAccessTokenTimer();
              this.clearIdTokenTimer();
            }
          }, {
            key: "clearAccessTokenTimer",
            value: function clearAccessTokenTimer() {
              if (this.accessTokenTimeoutSubscription) {
                this.accessTokenTimeoutSubscription.unsubscribe();
              }
            }
          }, {
            key: "clearIdTokenTimer",
            value: function clearIdTokenTimer() {
              if (this.idTokenTimeoutSubscription) {
                this.idTokenTimeoutSubscription.unsubscribe();
              }
            }
          }, {
            key: "calcTimeout",
            value: function calcTimeout(storedAt, expiration) {
              var now = Date.now();
              var delta = (expiration - storedAt) * this.timeoutFactor - (now - storedAt);
              return Math.max(0, delta);
            }
            /**
             * DEPRECATED. Use a provider for OAuthStorage instead:
             *
             * { provide: OAuthStorage, useFactory: oAuthStorageFactory }
             * export function oAuthStorageFactory(): OAuthStorage { return localStorage; }
             * Sets a custom storage used to store the received
             * tokens on client side. By default, the browser's
             * sessionStorage is used.
             * @ignore
             *
             * @param storage
             */

          }, {
            key: "setStorage",
            value: function setStorage(storage) {
              this._storage = storage;
              this.configChanged();
            }
            /**
             * Loads the discovery document to configure most
             * properties of this service. The url of the discovery
             * document is infered from the issuer's url according
             * to the OpenId Connect spec. To use another url you
             * can pass it to to optional parameter fullUrl.
             *
             * @param fullUrl
             */

          }, {
            key: "loadDiscoveryDocument",
            value: function loadDiscoveryDocument() {
              var _this12 = this;

              var fullUrl = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
              return new Promise(function (resolve, reject) {
                if (!fullUrl) {
                  fullUrl = _this12.issuer || '';

                  if (!fullUrl.endsWith('/')) {
                    fullUrl += '/';
                  }

                  fullUrl += '.well-known/openid-configuration';
                }

                if (!_this12.validateUrlForHttps(fullUrl)) {
                  reject("issuer  must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS).");
                  return;
                }

                _this12.http.get(fullUrl).subscribe(function (doc) {
                  if (!_this12.validateDiscoveryDocument(doc)) {
                    _this12.eventsSubject.next(new OAuthErrorEvent('discovery_document_validation_error', null));

                    reject('discovery_document_validation_error');
                    return;
                  }

                  _this12.loginUrl = doc.authorization_endpoint;
                  _this12.logoutUrl = doc.end_session_endpoint || _this12.logoutUrl;
                  _this12.grantTypesSupported = doc.grant_types_supported;
                  _this12.issuer = doc.issuer;
                  _this12.tokenEndpoint = doc.token_endpoint;
                  _this12.userinfoEndpoint = doc.userinfo_endpoint || _this12.userinfoEndpoint;
                  _this12.jwksUri = doc.jwks_uri;
                  _this12.sessionCheckIFrameUrl = doc.check_session_iframe || _this12.sessionCheckIFrameUrl;
                  _this12.discoveryDocumentLoaded = true;

                  _this12.discoveryDocumentLoadedSubject.next(doc);

                  _this12.revocationEndpoint = doc.revocation_endpoint;

                  if (_this12.sessionChecksEnabled) {
                    _this12.restartSessionChecksIfStillLoggedIn();
                  }

                  _this12.loadJwks().then(function (jwks) {
                    var result = {
                      discoveryDocument: doc,
                      jwks: jwks
                    };
                    var event = new OAuthSuccessEvent('discovery_document_loaded', result);

                    _this12.eventsSubject.next(event);

                    resolve(event);
                    return;
                  })["catch"](function (err) {
                    _this12.eventsSubject.next(new OAuthErrorEvent('discovery_document_load_error', err));

                    reject(err);
                    return;
                  });
                }, function (err) {
                  _this12.logger.error('error loading discovery document', err);

                  _this12.eventsSubject.next(new OAuthErrorEvent('discovery_document_load_error', err));

                  reject(err);
                });
              });
            }
          }, {
            key: "loadJwks",
            value: function loadJwks() {
              var _this13 = this;

              return new Promise(function (resolve, reject) {
                if (_this13.jwksUri) {
                  _this13.http.get(_this13.jwksUri).subscribe(function (jwks) {
                    _this13.jwks = jwks;

                    _this13.eventsSubject.next(new OAuthSuccessEvent('discovery_document_loaded'));

                    resolve(jwks);
                  }, function (err) {
                    _this13.logger.error('error loading jwks', err);

                    _this13.eventsSubject.next(new OAuthErrorEvent('jwks_load_error', err));

                    reject(err);
                  });
                } else {
                  resolve(null);
                }
              });
            }
          }, {
            key: "validateDiscoveryDocument",
            value: function validateDiscoveryDocument(doc) {
              var errors;

              if (!this.skipIssuerCheck && doc.issuer !== this.issuer) {
                this.logger.error('invalid issuer in discovery document', 'expected: ' + this.issuer, 'current: ' + doc.issuer);
                return false;
              }

              errors = this.validateUrlFromDiscoveryDocument(doc.authorization_endpoint);

              if (errors.length > 0) {
                this.logger.error('error validating authorization_endpoint in discovery document', errors);
                return false;
              }

              errors = this.validateUrlFromDiscoveryDocument(doc.end_session_endpoint);

              if (errors.length > 0) {
                this.logger.error('error validating end_session_endpoint in discovery document', errors);
                return false;
              }

              errors = this.validateUrlFromDiscoveryDocument(doc.token_endpoint);

              if (errors.length > 0) {
                this.logger.error('error validating token_endpoint in discovery document', errors);
              }

              errors = this.validateUrlFromDiscoveryDocument(doc.revocation_endpoint);

              if (errors.length > 0) {
                this.logger.error('error validating revocation_endpoint in discovery document', errors);
              }

              errors = this.validateUrlFromDiscoveryDocument(doc.userinfo_endpoint);

              if (errors.length > 0) {
                this.logger.error('error validating userinfo_endpoint in discovery document', errors);
                return false;
              }

              errors = this.validateUrlFromDiscoveryDocument(doc.jwks_uri);

              if (errors.length > 0) {
                this.logger.error('error validating jwks_uri in discovery document', errors);
                return false;
              }

              if (this.sessionChecksEnabled && !doc.check_session_iframe) {
                this.logger.warn('sessionChecksEnabled is activated but discovery document' + ' does not contain a check_session_iframe field');
              }

              return true;
            }
            /**
             * Uses password flow to exchange userName and password for an
             * access_token. After receiving the access_token, this method
             * uses it to query the userinfo endpoint in order to get information
             * about the user in question.
             *
             * When using this, make sure that the property oidc is set to false.
             * Otherwise stricter validations take place that make this operation
             * fail.
             *
             * @param userName
             * @param password
             * @param headers Optional additional http-headers.
             */

          }, {
            key: "fetchTokenUsingPasswordFlowAndLoadUserProfile",
            value: function fetchTokenUsingPasswordFlowAndLoadUserProfile(userName, password) {
              var _this14 = this;

              var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
              return this.fetchTokenUsingPasswordFlow(userName, password, headers).then(function () {
                return _this14.loadUserProfile();
              });
            }
            /**
             * Loads the user profile by accessing the user info endpoint defined by OpenId Connect.
             *
             * When using this with OAuth2 password flow, make sure that the property oidc is set to false.
             * Otherwise stricter validations take place that make this operation fail.
             */

          }, {
            key: "loadUserProfile",
            value: function loadUserProfile() {
              var _this15 = this;

              if (!this.hasValidAccessToken()) {
                throw new Error('Can not load User Profile without access_token');
              }

              if (!this.validateUrlForHttps(this.userinfoEndpoint)) {
                throw new Error("userinfoEndpoint must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS).");
              }

              return new Promise(function (resolve, reject) {
                var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('Authorization', 'Bearer ' + _this15.getAccessToken());

                _this15.http.get(_this15.userinfoEndpoint, {
                  headers: headers
                }).subscribe(function (info) {
                  _this15.debug('userinfo received', info);

                  var existingClaims = _this15.getIdentityClaims() || {};

                  if (!_this15.skipSubjectCheck) {
                    if (_this15.oidc && (!existingClaims['sub'] || info.sub !== existingClaims['sub'])) {
                      var _err = 'if property oidc is true, the received user-id (sub) has to be the user-id ' + 'of the user that has logged in with oidc.\n' + 'if you are not using oidc but just oauth2 password flow set oidc to false';

                      reject(_err);
                      return;
                    }
                  }

                  info = Object.assign({}, existingClaims, info);

                  _this15._storage.setItem('id_token_claims_obj', JSON.stringify(info));

                  _this15.eventsSubject.next(new OAuthSuccessEvent('user_profile_loaded'));

                  resolve(info);
                }, function (err) {
                  _this15.logger.error('error loading user info', err);

                  _this15.eventsSubject.next(new OAuthErrorEvent('user_profile_load_error', err));

                  reject(err);
                });
              });
            }
            /**
             * Uses password flow to exchange userName and password for an access_token.
             * @param userName
             * @param password
             * @param headers Optional additional http-headers.
             */

          }, {
            key: "fetchTokenUsingPasswordFlow",
            value: function fetchTokenUsingPasswordFlow(userName, password) {
              var _this16 = this;

              var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
              this.assertUrlNotNullAndCorrectProtocol(this.tokenEndpoint, 'tokenEndpoint');
              return new Promise(function (resolve, reject) {
                /**
                 * A `HttpParameterCodec` that uses `encodeURIComponent` and `decodeURIComponent` to
                 * serialize and parse URL parameter keys and values.
                 *
                 * @stable
                 */
                var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({
                  encoder: new WebHttpUrlEncodingCodec()
                }).set('grant_type', 'password').set('scope', _this16.scope).set('username', userName).set('password', password);

                if (_this16.useHttpBasicAuth) {
                  var header = btoa("".concat(_this16.clientId, ":").concat(_this16.dummyClientSecret));
                  headers = headers.set('Authorization', 'Basic ' + header);
                }

                if (!_this16.useHttpBasicAuth) {
                  params = params.set('client_id', _this16.clientId);
                }

                if (!_this16.useHttpBasicAuth && _this16.dummyClientSecret) {
                  params = params.set('client_secret', _this16.dummyClientSecret);
                }

                if (_this16.customQueryParams) {
                  var _iterator3 = _createForOfIteratorHelper(Object.getOwnPropertyNames(_this16.customQueryParams)),
                      _step3;

                  try {
                    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                      var key = _step3.value;
                      params = params.set(key, _this16.customQueryParams[key]);
                    }
                  } catch (err) {
                    _iterator3.e(err);
                  } finally {
                    _iterator3.f();
                  }
                }

                headers = headers.set('Content-Type', 'application/x-www-form-urlencoded');

                _this16.http.post(_this16.tokenEndpoint, params, {
                  headers: headers
                }).subscribe(function (tokenResponse) {
                  _this16.debug('tokenResponse', tokenResponse);

                  _this16.storeAccessTokenResponse(tokenResponse.access_token, tokenResponse.refresh_token, tokenResponse.expires_in || _this16.fallbackAccessTokenExpirationTimeInSec, tokenResponse.scope, _this16.extractRecognizedCustomParameters(tokenResponse));

                  _this16.eventsSubject.next(new OAuthSuccessEvent('token_received'));

                  resolve(tokenResponse);
                }, function (err) {
                  _this16.logger.error('Error performing password flow', err);

                  _this16.eventsSubject.next(new OAuthErrorEvent('token_error', err));

                  reject(err);
                });
              });
            }
            /**
             * Refreshes the token using a refresh_token.
             * This does not work for implicit flow, b/c
             * there is no refresh_token in this flow.
             * A solution for this is provided by the
             * method silentRefresh.
             */

          }, {
            key: "refreshToken",
            value: function refreshToken() {
              var _this17 = this;

              this.assertUrlNotNullAndCorrectProtocol(this.tokenEndpoint, 'tokenEndpoint');
              return new Promise(function (resolve, reject) {
                var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('grant_type', 'refresh_token').set('scope', _this17.scope).set('refresh_token', _this17._storage.getItem('refresh_token'));
                var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('Content-Type', 'application/x-www-form-urlencoded');

                if (_this17.useHttpBasicAuth) {
                  var header = btoa("".concat(_this17.clientId, ":").concat(_this17.dummyClientSecret));
                  headers = headers.set('Authorization', 'Basic ' + header);
                }

                if (!_this17.useHttpBasicAuth) {
                  params = params.set('client_id', _this17.clientId);
                }

                if (!_this17.useHttpBasicAuth && _this17.dummyClientSecret) {
                  params = params.set('client_secret', _this17.dummyClientSecret);
                }

                if (_this17.customQueryParams) {
                  var _iterator4 = _createForOfIteratorHelper(Object.getOwnPropertyNames(_this17.customQueryParams)),
                      _step4;

                  try {
                    for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                      var key = _step4.value;
                      params = params.set(key, _this17.customQueryParams[key]);
                    }
                  } catch (err) {
                    _iterator4.e(err);
                  } finally {
                    _iterator4.f();
                  }
                }

                _this17.http.post(_this17.tokenEndpoint, params, {
                  headers: headers
                }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])(function (tokenResponse) {
                  if (tokenResponse.id_token) {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["from"])(_this17.processIdToken(tokenResponse.id_token, tokenResponse.access_token, true)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["tap"])(function (result) {
                      return _this17.storeIdToken(result);
                    }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (_) {
                      return tokenResponse;
                    }));
                  } else {
                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(tokenResponse);
                  }
                })).subscribe(function (tokenResponse) {
                  _this17.debug('refresh tokenResponse', tokenResponse);

                  _this17.storeAccessTokenResponse(tokenResponse.access_token, tokenResponse.refresh_token, tokenResponse.expires_in || _this17.fallbackAccessTokenExpirationTimeInSec, tokenResponse.scope, _this17.extractRecognizedCustomParameters(tokenResponse));

                  _this17.eventsSubject.next(new OAuthSuccessEvent('token_received'));

                  _this17.eventsSubject.next(new OAuthSuccessEvent('token_refreshed'));

                  resolve(tokenResponse);
                }, function (err) {
                  _this17.logger.error('Error refreshing token', err);

                  _this17.eventsSubject.next(new OAuthErrorEvent('token_refresh_error', err));

                  reject(err);
                });
              });
            }
          }, {
            key: "removeSilentRefreshEventListener",
            value: function removeSilentRefreshEventListener() {
              if (this.silentRefreshPostMessageEventListener) {
                window.removeEventListener('message', this.silentRefreshPostMessageEventListener);
                this.silentRefreshPostMessageEventListener = null;
              }
            }
          }, {
            key: "setupSilentRefreshEventListener",
            value: function setupSilentRefreshEventListener() {
              var _this18 = this;

              this.removeSilentRefreshEventListener();

              this.silentRefreshPostMessageEventListener = function (e) {
                var message = _this18.processMessageEventMessage(e);

                _this18.tryLogin({
                  customHashFragment: message,
                  preventClearHashAfterLogin: true,
                  customRedirectUri: _this18.silentRefreshRedirectUri || _this18.redirectUri
                })["catch"](function (err) {
                  return _this18.debug('tryLogin during silent refresh failed', err);
                });
              };

              window.addEventListener('message', this.silentRefreshPostMessageEventListener);
            }
            /**
             * Performs a silent refresh for implicit flow.
             * Use this method to get new tokens when/before
             * the existing tokens expire.
             */

          }, {
            key: "silentRefresh",
            value: function silentRefresh() {
              var _this19 = this;

              var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
              var noPrompt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
              var claims = this.getIdentityClaims() || {};

              if (this.useIdTokenHintForSilentRefresh && this.hasValidIdToken()) {
                params['id_token_hint'] = this.getIdToken();
              }

              if (!this.validateUrlForHttps(this.loginUrl)) {
                throw new Error("loginUrl  must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS).");
              }

              if (typeof this.document === 'undefined') {
                throw new Error('silent refresh is not supported on this platform');
              }

              var existingIframe = this.document.getElementById(this.silentRefreshIFrameName);

              if (existingIframe) {
                this.document.body.removeChild(existingIframe);
              }

              this.silentRefreshSubject = claims['sub'];
              var iframe = this.document.createElement('iframe');
              iframe.id = this.silentRefreshIFrameName;
              this.setupSilentRefreshEventListener();
              var redirectUri = this.silentRefreshRedirectUri || this.redirectUri;
              this.createLoginUrl(null, null, redirectUri, noPrompt, params).then(function (url) {
                iframe.setAttribute('src', url);

                if (!_this19.silentRefreshShowIFrame) {
                  iframe.style['display'] = 'none';
                }

                _this19.document.body.appendChild(iframe);
              });
              var errors = this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e instanceof OAuthErrorEvent;
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["first"])());
              var success = this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e.type === 'token_received';
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["first"])());
              var timeout = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(new OAuthErrorEvent('silent_refresh_timeout', null)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["delay"])(this.silentRefreshTimeout));
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["race"])([errors, success, timeout]).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (e) {
                if (e instanceof OAuthErrorEvent) {
                  if (e.type === 'silent_refresh_timeout') {
                    _this19.eventsSubject.next(e);
                  } else {
                    e = new OAuthErrorEvent('silent_refresh_error', e);

                    _this19.eventsSubject.next(e);
                  }

                  throw e;
                } else if (e.type === 'token_received') {
                  e = new OAuthSuccessEvent('silently_refreshed');

                  _this19.eventsSubject.next(e);
                }

                return e;
              })).toPromise();
            }
            /**
             * This method exists for backwards compatibility.
             * {@link OAuthService#initLoginFlowInPopup} handles both code
             * and implicit flows.
             */

          }, {
            key: "initImplicitFlowInPopup",
            value: function initImplicitFlowInPopup(options) {
              return this.initLoginFlowInPopup(options);
            }
          }, {
            key: "initLoginFlowInPopup",
            value: function initLoginFlowInPopup(options) {
              var _this20 = this;

              options = options || {};
              return this.createLoginUrl(null, null, this.silentRefreshRedirectUri, false, {
                display: 'popup'
              }).then(function (url) {
                return new Promise(function (resolve, reject) {
                  /**
                   * Error handling section
                   */
                  var checkForPopupClosedInterval = 500;
                  var windowRef = window.open(url, '_blank', _this20.calculatePopupFeatures(options));
                  var checkForPopupClosedTimer;

                  var checkForPopupClosed = function checkForPopupClosed() {
                    if (!windowRef || windowRef.closed) {
                      cleanup();
                      reject(new OAuthErrorEvent('popup_closed', {}));
                    }
                  };

                  if (!windowRef) {
                    reject(new OAuthErrorEvent('popup_blocked', {}));
                  } else {
                    checkForPopupClosedTimer = window.setInterval(checkForPopupClosed, checkForPopupClosedInterval);
                  }

                  var cleanup = function cleanup() {
                    window.clearInterval(checkForPopupClosedTimer);
                    window.removeEventListener('message', listener);

                    if (windowRef !== null) {
                      windowRef.close();
                    }

                    windowRef = null;
                  };

                  var listener = function listener(e) {
                    var message = _this20.processMessageEventMessage(e);

                    if (message && message !== null) {
                      _this20.tryLogin({
                        customHashFragment: message,
                        preventClearHashAfterLogin: true,
                        customRedirectUri: _this20.silentRefreshRedirectUri
                      }).then(function () {
                        cleanup();
                        resolve();
                      }, function (err) {
                        cleanup();
                        reject(err);
                      });
                    } else {
                      console.log('false event firing');
                    }
                  };

                  window.addEventListener('message', listener);
                });
              });
            }
          }, {
            key: "calculatePopupFeatures",
            value: function calculatePopupFeatures(options) {
              // Specify an static height and width and calculate centered position
              var height = options.height || 470;
              var width = options.width || 500;
              var left = window.screenLeft + (window.outerWidth - width) / 2;
              var top = window.screenTop + (window.outerHeight - height) / 2;
              return "location=no,toolbar=no,width=".concat(width, ",height=").concat(height, ",top=").concat(top, ",left=").concat(left);
            }
          }, {
            key: "processMessageEventMessage",
            value: function processMessageEventMessage(e) {
              var expectedPrefix = '#';

              if (this.silentRefreshMessagePrefix) {
                expectedPrefix += this.silentRefreshMessagePrefix;
              }

              if (!e || !e.data || typeof e.data !== 'string') {
                return;
              }

              var prefixedMessage = e.data;

              if (!prefixedMessage.startsWith(expectedPrefix)) {
                return;
              }

              return '#' + prefixedMessage.substr(expectedPrefix.length);
            }
          }, {
            key: "canPerformSessionCheck",
            value: function canPerformSessionCheck() {
              if (!this.sessionChecksEnabled) {
                return false;
              }

              if (!this.sessionCheckIFrameUrl) {
                console.warn('sessionChecksEnabled is activated but there is no sessionCheckIFrameUrl');
                return false;
              }

              var sessionState = this.getSessionState();

              if (!sessionState) {
                console.warn('sessionChecksEnabled is activated but there is no session_state');
                return false;
              }

              if (typeof this.document === 'undefined') {
                return false;
              }

              return true;
            }
          }, {
            key: "setupSessionCheckEventListener",
            value: function setupSessionCheckEventListener() {
              var _this21 = this;

              this.removeSessionCheckEventListener();

              this.sessionCheckEventListener = function (e) {
                var origin = e.origin.toLowerCase();

                var issuer = _this21.issuer.toLowerCase();

                _this21.debug('sessionCheckEventListener');

                if (!issuer.startsWith(origin)) {
                  _this21.debug('sessionCheckEventListener', 'wrong origin', origin, 'expected', issuer, 'event', e);

                  return;
                } // only run in Angular zone if it is 'changed' or 'error'


                switch (e.data) {
                  case 'unchanged':
                    _this21.handleSessionUnchanged();

                    break;

                  case 'changed':
                    _this21.ngZone.run(function () {
                      _this21.handleSessionChange();
                    });

                    break;

                  case 'error':
                    _this21.ngZone.run(function () {
                      _this21.handleSessionError();
                    });

                    break;
                }

                _this21.debug('got info from session check inframe', e);
              }; // prevent Angular from refreshing the view on every message (runs in intervals)


              this.ngZone.runOutsideAngular(function () {
                window.addEventListener('message', _this21.sessionCheckEventListener);
              });
            }
          }, {
            key: "handleSessionUnchanged",
            value: function handleSessionUnchanged() {
              this.debug('session check', 'session unchanged');
            }
          }, {
            key: "handleSessionChange",
            value: function handleSessionChange() {
              var _this22 = this;

              this.eventsSubject.next(new OAuthInfoEvent('session_changed'));
              this.stopSessionCheckTimer();

              if (!this.useSilentRefresh && this.responseType === 'code') {
                this.refreshToken().then(function (_) {
                  _this22.debug('token refresh after session change worked');
                })["catch"](function (_) {
                  _this22.debug('token refresh did not work after session changed');

                  _this22.eventsSubject.next(new OAuthInfoEvent('session_terminated'));

                  _this22.logOut(true);
                });
              } else if (this.silentRefreshRedirectUri) {
                this.silentRefresh()["catch"](function (_) {
                  return _this22.debug('silent refresh failed after session changed');
                });
                this.waitForSilentRefreshAfterSessionChange();
              } else {
                this.eventsSubject.next(new OAuthInfoEvent('session_terminated'));
                this.logOut(true);
              }
            }
          }, {
            key: "waitForSilentRefreshAfterSessionChange",
            value: function waitForSilentRefreshAfterSessionChange() {
              var _this23 = this;

              this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e.type === 'silently_refreshed' || e.type === 'silent_refresh_timeout' || e.type === 'silent_refresh_error';
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["first"])()).subscribe(function (e) {
                if (e.type !== 'silently_refreshed') {
                  _this23.debug('silent refresh did not work after session changed');

                  _this23.eventsSubject.next(new OAuthInfoEvent('session_terminated'));

                  _this23.logOut(true);
                }
              });
            }
          }, {
            key: "handleSessionError",
            value: function handleSessionError() {
              this.stopSessionCheckTimer();
              this.eventsSubject.next(new OAuthInfoEvent('session_error'));
            }
          }, {
            key: "removeSessionCheckEventListener",
            value: function removeSessionCheckEventListener() {
              if (this.sessionCheckEventListener) {
                window.removeEventListener('message', this.sessionCheckEventListener);
                this.sessionCheckEventListener = null;
              }
            }
          }, {
            key: "initSessionCheck",
            value: function initSessionCheck() {
              if (!this.canPerformSessionCheck()) {
                return;
              }

              var existingIframe = this.document.getElementById(this.sessionCheckIFrameName);

              if (existingIframe) {
                this.document.body.removeChild(existingIframe);
              }

              var iframe = this.document.createElement('iframe');
              iframe.id = this.sessionCheckIFrameName;
              this.setupSessionCheckEventListener();
              var url = this.sessionCheckIFrameUrl;
              iframe.setAttribute('src', url);
              iframe.style.display = 'none';
              this.document.body.appendChild(iframe);
              this.startSessionCheckTimer();
            }
          }, {
            key: "startSessionCheckTimer",
            value: function startSessionCheckTimer() {
              var _this24 = this;

              this.stopSessionCheckTimer();
              this.ngZone.runOutsideAngular(function () {
                _this24.sessionCheckTimer = setInterval(_this24.checkSession.bind(_this24), _this24.sessionCheckIntervall);
              });
            }
          }, {
            key: "stopSessionCheckTimer",
            value: function stopSessionCheckTimer() {
              if (this.sessionCheckTimer) {
                clearInterval(this.sessionCheckTimer);
                this.sessionCheckTimer = null;
              }
            }
          }, {
            key: "checkSession",
            value: function checkSession() {
              var iframe = this.document.getElementById(this.sessionCheckIFrameName);

              if (!iframe) {
                this.logger.warn('checkSession did not find iframe', this.sessionCheckIFrameName);
              }

              var sessionState = this.getSessionState();

              if (!sessionState) {
                this.stopSessionCheckTimer();
              }

              var message = this.clientId + ' ' + sessionState;
              iframe.contentWindow.postMessage(message, this.issuer);
            }
          }, {
            key: "createLoginUrl",
            value: function createLoginUrl() {
              var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var loginHint = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
              var customRedirectUri = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
              var noPrompt = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
              var params = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
              return Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                var that, redirectUri, nonce, seperationChar, scope, url, _yield$this$createCha, _yield$this$createCha2, challenge, verifier, _i2, _Object$keys, key, _iterator5, _step5, _key2;

                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                  while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        that = this;

                        if (customRedirectUri) {
                          redirectUri = customRedirectUri;
                        } else {
                          redirectUri = this.redirectUri;
                        }

                        _context3.next = 4;
                        return this.createAndSaveNonce();

                      case 4:
                        nonce = _context3.sent;

                        if (state) {
                          state = nonce + this.config.nonceStateSeparator + encodeURIComponent(state);
                        } else {
                          state = nonce;
                        }

                        if (!(!this.requestAccessToken && !this.oidc)) {
                          _context3.next = 8;
                          break;
                        }

                        throw new Error('Either requestAccessToken or oidc or both must be true');

                      case 8:
                        if (this.config.responseType) {
                          this.responseType = this.config.responseType;
                        } else {
                          if (this.oidc && this.requestAccessToken) {
                            this.responseType = 'id_token token';
                          } else if (this.oidc && !this.requestAccessToken) {
                            this.responseType = 'id_token';
                          } else {
                            this.responseType = 'token';
                          }
                        }

                        seperationChar = that.loginUrl.indexOf('?') > -1 ? '&' : '?';
                        scope = that.scope;

                        if (this.oidc && !scope.match(/(^|\s)openid($|\s)/)) {
                          scope = 'openid ' + scope;
                        }

                        url = that.loginUrl + seperationChar + 'response_type=' + encodeURIComponent(that.responseType) + '&client_id=' + encodeURIComponent(that.clientId) + '&state=' + encodeURIComponent(state) + '&redirect_uri=' + encodeURIComponent(redirectUri) + '&scope=' + encodeURIComponent(scope);

                        if (!(this.responseType.includes('code') && !this.disablePKCE)) {
                          _context3.next = 23;
                          break;
                        }

                        _context3.next = 16;
                        return this.createChallangeVerifierPairForPKCE();

                      case 16:
                        _yield$this$createCha = _context3.sent;
                        _yield$this$createCha2 = _slicedToArray(_yield$this$createCha, 2);
                        challenge = _yield$this$createCha2[0];
                        verifier = _yield$this$createCha2[1];

                        if (this.saveNoncesInLocalStorage && typeof window['localStorage'] !== 'undefined') {
                          localStorage.setItem('PKCE_verifier', verifier);
                        } else {
                          this._storage.setItem('PKCE_verifier', verifier);
                        }

                        url += '&code_challenge=' + challenge;
                        url += '&code_challenge_method=S256';

                      case 23:
                        if (loginHint) {
                          url += '&login_hint=' + encodeURIComponent(loginHint);
                        }

                        if (that.resource) {
                          url += '&resource=' + encodeURIComponent(that.resource);
                        }

                        if (that.oidc) {
                          url += '&nonce=' + encodeURIComponent(nonce);
                        }

                        if (noPrompt) {
                          url += '&prompt=none';
                        }

                        for (_i2 = 0, _Object$keys = Object.keys(params); _i2 < _Object$keys.length; _i2++) {
                          key = _Object$keys[_i2];
                          url += '&' + encodeURIComponent(key) + '=' + encodeURIComponent(params[key]);
                        }

                        if (this.customQueryParams) {
                          _iterator5 = _createForOfIteratorHelper(Object.getOwnPropertyNames(this.customQueryParams));

                          try {
                            for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
                              _key2 = _step5.value;
                              url += '&' + _key2 + '=' + encodeURIComponent(this.customQueryParams[_key2]);
                            }
                          } catch (err) {
                            _iterator5.e(err);
                          } finally {
                            _iterator5.f();
                          }
                        }

                        return _context3.abrupt("return", url);

                      case 30:
                      case "end":
                        return _context3.stop();
                    }
                  }
                }, _callee3, this);
              }));
            }
          }, {
            key: "initImplicitFlowInternal",
            value: function initImplicitFlowInternal() {
              var _this25 = this;

              var additionalState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

              if (this.inImplicitFlow) {
                return;
              }

              this.inImplicitFlow = true;

              if (!this.validateUrlForHttps(this.loginUrl)) {
                throw new Error("loginUrl  must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS).");
              }

              var addParams = {};
              var loginHint = null;

              if (typeof params === 'string') {
                loginHint = params;
              } else if (typeof params === 'object') {
                addParams = params;
              }

              this.createLoginUrl(additionalState, loginHint, null, false, addParams).then(this.config.openUri)["catch"](function (error) {
                console.error('Error in initImplicitFlow', error);
                _this25.inImplicitFlow = false;
              });
            }
            /**
             * Starts the implicit flow and redirects to user to
             * the auth servers' login url.
             *
             * @param additionalState Optional state that is passed around.
             *  You'll find this state in the property `state` after `tryLogin` logged in the user.
             * @param params Hash with additional parameter. If it is a string, it is used for the
             *               parameter loginHint (for the sake of compatibility with former versions)
             */

          }, {
            key: "initImplicitFlow",
            value: function initImplicitFlow() {
              var _this26 = this;

              var additionalState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

              if (this.loginUrl !== '') {
                this.initImplicitFlowInternal(additionalState, params);
              } else {
                this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                  return e.type === 'discovery_document_loaded';
                })).subscribe(function (_) {
                  return _this26.initImplicitFlowInternal(additionalState, params);
                });
              }
            }
            /**
             * Reset current implicit flow
             *
             * @description This method allows resetting the current implict flow in order to be initialized again.
             */

          }, {
            key: "resetImplicitFlow",
            value: function resetImplicitFlow() {
              this.inImplicitFlow = false;
            }
          }, {
            key: "callOnTokenReceivedIfExists",
            value: function callOnTokenReceivedIfExists(options) {
              var that = this;

              if (options.onTokenReceived) {
                var tokenParams = {
                  idClaims: that.getIdentityClaims(),
                  idToken: that.getIdToken(),
                  accessToken: that.getAccessToken(),
                  state: that.state
                };
                options.onTokenReceived(tokenParams);
              }
            }
          }, {
            key: "storeAccessTokenResponse",
            value: function storeAccessTokenResponse(accessToken, refreshToken, expiresIn, grantedScopes, customParameters) {
              var _this27 = this;

              this._storage.setItem('access_token', accessToken);

              if (grantedScopes && !Array.isArray(grantedScopes)) {
                this._storage.setItem('granted_scopes', JSON.stringify(grantedScopes.split('+')));
              } else if (grantedScopes && Array.isArray(grantedScopes)) {
                this._storage.setItem('granted_scopes', JSON.stringify(grantedScopes));
              }

              this._storage.setItem('access_token_stored_at', '' + Date.now());

              if (expiresIn) {
                var expiresInMilliSeconds = expiresIn * 1000;
                var now = new Date();
                var expiresAt = now.getTime() + expiresInMilliSeconds;

                this._storage.setItem('expires_at', '' + expiresAt);
              }

              if (refreshToken) {
                this._storage.setItem('refresh_token', refreshToken);
              }

              if (customParameters) {
                customParameters.forEach(function (value, key) {
                  _this27._storage.setItem(key, value);
                });
              }
            }
            /**
             * Delegates to tryLoginImplicitFlow for the sake of competability
             * @param options Optional options.
             */

          }, {
            key: "tryLogin",
            value: function tryLogin() {
              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

              if (this.config.responseType === 'code') {
                return this.tryLoginCodeFlow(options).then(function (_) {
                  return true;
                });
              } else {
                return this.tryLoginImplicitFlow(options);
              }
            }
          }, {
            key: "parseQueryString",
            value: function parseQueryString(queryString) {
              if (!queryString || queryString.length === 0) {
                return {};
              }

              if (queryString.charAt(0) === '?') {
                queryString = queryString.substr(1);
              }

              return this.urlHelper.parseQueryString(queryString);
            }
          }, {
            key: "tryLoginCodeFlow",
            value: function tryLoginCodeFlow() {
              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
              options = options || {};
              var querySource = options.customHashFragment ? options.customHashFragment.substring(1) : window.location.search;
              var parts = this.getCodePartsFromUrl(querySource);
              var code = parts['code'];
              var state = parts['state'];
              var sessionState = parts['session_state'];

              if (!options.preventClearHashAfterLogin) {
                var href = location.href.replace(/[&\?]code=[^&\$]*/, '').replace(/[&\?]scope=[^&\$]*/, '').replace(/[&\?]state=[^&\$]*/, '').replace(/[&\?]session_state=[^&\$]*/, '');
                history.replaceState(null, window.name, href);
              }

              var _this$parseState = this.parseState(state),
                  _this$parseState2 = _slicedToArray(_this$parseState, 2),
                  nonceInState = _this$parseState2[0],
                  userState = _this$parseState2[1];

              this.state = userState;

              if (parts['error']) {
                this.debug('error trying to login');
                this.handleLoginError({}, parts);

                var _err2 = new OAuthErrorEvent('code_error', {}, parts);

                this.eventsSubject.next(_err2);
                return Promise.reject(_err2);
              }

              if (!nonceInState) {
                return Promise.resolve();
              }

              var success = this.validateNonce(nonceInState);

              if (!success) {
                var event = new OAuthErrorEvent('invalid_nonce_in_state', null);
                this.eventsSubject.next(event);
                return Promise.reject(event);
              }

              this.storeSessionState(sessionState);

              if (code) {
                return this.getTokenFromCode(code, options).then(function (_) {
                  return null;
                });
              } else {
                return Promise.resolve();
              }
            }
            /**
             * Retrieve the returned auth code from the redirect uri that has been called.
             * If required also check hash, as we could use hash location strategy.
             */

          }, {
            key: "getCodePartsFromUrl",
            value: function getCodePartsFromUrl(queryString) {
              if (!queryString || queryString.length === 0) {
                return this.urlHelper.getHashFragmentParams();
              } // normalize query string


              if (queryString.charAt(0) === '?') {
                queryString = queryString.substr(1);
              }

              return this.urlHelper.parseQueryString(queryString);
            }
            /**
             * Get token using an intermediate code. Works for the Authorization Code flow.
             */

          }, {
            key: "getTokenFromCode",
            value: function getTokenFromCode(code, options) {
              var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('grant_type', 'authorization_code').set('code', code).set('redirect_uri', options.customRedirectUri || this.redirectUri);

              if (!this.disablePKCE) {
                var PKCEVerifier;

                if (this.saveNoncesInLocalStorage && typeof window['localStorage'] !== 'undefined') {
                  PKCEVerifier = localStorage.getItem('PKCE_verifier');
                } else {
                  PKCEVerifier = this._storage.getItem('PKCE_verifier');
                }

                if (!PKCEVerifier) {
                  console.warn('No PKCE verifier found in oauth storage!');
                } else {
                  params = params.set('code_verifier', PKCEVerifier);
                }
              }

              return this.fetchAndProcessToken(params);
            }
          }, {
            key: "fetchAndProcessToken",
            value: function fetchAndProcessToken(params) {
              var _this28 = this;

              this.assertUrlNotNullAndCorrectProtocol(this.tokenEndpoint, 'tokenEndpoint');
              var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('Content-Type', 'application/x-www-form-urlencoded');

              if (this.useHttpBasicAuth) {
                var header = btoa("".concat(this.clientId, ":").concat(this.dummyClientSecret));
                headers = headers.set('Authorization', 'Basic ' + header);
              }

              if (!this.useHttpBasicAuth) {
                params = params.set('client_id', this.clientId);
              }

              if (!this.useHttpBasicAuth && this.dummyClientSecret) {
                params = params.set('client_secret', this.dummyClientSecret);
              }

              return new Promise(function (resolve, reject) {
                if (_this28.customQueryParams) {
                  var _iterator6 = _createForOfIteratorHelper(Object.getOwnPropertyNames(_this28.customQueryParams)),
                      _step6;

                  try {
                    for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                      var key = _step6.value;
                      params = params.set(key, _this28.customQueryParams[key]);
                    }
                  } catch (err) {
                    _iterator6.e(err);
                  } finally {
                    _iterator6.f();
                  }
                }

                _this28.http.post(_this28.tokenEndpoint, params, {
                  headers: headers
                }).subscribe(function (tokenResponse) {
                  _this28.debug('refresh tokenResponse', tokenResponse);

                  _this28.storeAccessTokenResponse(tokenResponse.access_token, tokenResponse.refresh_token, tokenResponse.expires_in || _this28.fallbackAccessTokenExpirationTimeInSec, tokenResponse.scope, _this28.extractRecognizedCustomParameters(tokenResponse));

                  if (_this28.oidc && tokenResponse.id_token) {
                    _this28.processIdToken(tokenResponse.id_token, tokenResponse.access_token).then(function (result) {
                      _this28.storeIdToken(result);

                      _this28.eventsSubject.next(new OAuthSuccessEvent('token_received'));

                      _this28.eventsSubject.next(new OAuthSuccessEvent('token_refreshed'));

                      resolve(tokenResponse);
                    })["catch"](function (reason) {
                      _this28.eventsSubject.next(new OAuthErrorEvent('token_validation_error', reason));

                      console.error('Error validating tokens');
                      console.error(reason);
                      reject(reason);
                    });
                  } else {
                    _this28.eventsSubject.next(new OAuthSuccessEvent('token_received'));

                    _this28.eventsSubject.next(new OAuthSuccessEvent('token_refreshed'));

                    resolve(tokenResponse);
                  }
                }, function (err) {
                  console.error('Error getting token', err);

                  _this28.eventsSubject.next(new OAuthErrorEvent('token_refresh_error', err));

                  reject(err);
                });
              });
            }
            /**
             * Checks whether there are tokens in the hash fragment
             * as a result of the implicit flow. These tokens are
             * parsed, validated and used to sign the user in to the
             * current client.
             *
             * @param options Optional options.
             */

          }, {
            key: "tryLoginImplicitFlow",
            value: function tryLoginImplicitFlow() {
              var _this29 = this;

              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
              options = options || {};
              var parts;

              if (options.customHashFragment) {
                parts = this.urlHelper.getHashFragmentParams(options.customHashFragment);
              } else {
                parts = this.urlHelper.getHashFragmentParams();
              }

              this.debug('parsed url', parts);
              var state = parts['state'];

              var _this$parseState3 = this.parseState(state),
                  _this$parseState4 = _slicedToArray(_this$parseState3, 2),
                  nonceInState = _this$parseState4[0],
                  userState = _this$parseState4[1];

              this.state = userState;

              if (parts['error']) {
                this.debug('error trying to login');
                this.handleLoginError(options, parts);

                var _err3 = new OAuthErrorEvent('token_error', {}, parts);

                this.eventsSubject.next(_err3);
                return Promise.reject(_err3);
              }

              var accessToken = parts['access_token'];
              var idToken = parts['id_token'];
              var sessionState = parts['session_state'];
              var grantedScopes = parts['scope'];

              if (!this.requestAccessToken && !this.oidc) {
                return Promise.reject('Either requestAccessToken or oidc (or both) must be true.');
              }

              if (this.requestAccessToken && !accessToken) {
                return Promise.resolve(false);
              }

              if (this.requestAccessToken && !options.disableOAuth2StateCheck && !state) {
                return Promise.resolve(false);
              }

              if (this.oidc && !idToken) {
                return Promise.resolve(false);
              }

              if (this.sessionChecksEnabled && !sessionState) {
                this.logger.warn('session checks (Session Status Change Notification) ' + 'were activated in the configuration but the id_token ' + 'does not contain a session_state claim');
              }

              if (this.requestAccessToken && !options.disableOAuth2StateCheck) {
                var success = this.validateNonce(nonceInState);

                if (!success) {
                  var event = new OAuthErrorEvent('invalid_nonce_in_state', null);
                  this.eventsSubject.next(event);
                  return Promise.reject(event);
                }
              }

              if (this.requestAccessToken) {
                this.storeAccessTokenResponse(accessToken, null, parts['expires_in'] || this.fallbackAccessTokenExpirationTimeInSec, grantedScopes);
              }

              if (!this.oidc) {
                this.eventsSubject.next(new OAuthSuccessEvent('token_received'));

                if (this.clearHashAfterLogin && !options.preventClearHashAfterLogin) {
                  location.hash = '';
                }

                this.callOnTokenReceivedIfExists(options);
                return Promise.resolve(true);
              }

              return this.processIdToken(idToken, accessToken).then(function (result) {
                if (options.validationHandler) {
                  return options.validationHandler({
                    accessToken: accessToken,
                    idClaims: result.idTokenClaims,
                    idToken: result.idToken,
                    state: state
                  }).then(function (_) {
                    return result;
                  });
                }

                return result;
              }).then(function (result) {
                _this29.storeIdToken(result);

                _this29.storeSessionState(sessionState);

                if (_this29.clearHashAfterLogin && !options.preventClearHashAfterLogin) {
                  location.hash = '';
                }

                _this29.eventsSubject.next(new OAuthSuccessEvent('token_received'));

                _this29.callOnTokenReceivedIfExists(options);

                _this29.inImplicitFlow = false;
                return true;
              })["catch"](function (reason) {
                _this29.eventsSubject.next(new OAuthErrorEvent('token_validation_error', reason));

                _this29.logger.error('Error validating tokens');

                _this29.logger.error(reason);

                return Promise.reject(reason);
              });
            }
          }, {
            key: "parseState",
            value: function parseState(state) {
              var nonce = state;
              var userState = '';

              if (state) {
                var idx = state.indexOf(this.config.nonceStateSeparator);

                if (idx > -1) {
                  nonce = state.substr(0, idx);
                  userState = state.substr(idx + this.config.nonceStateSeparator.length);
                }
              }

              return [nonce, userState];
            }
          }, {
            key: "validateNonce",
            value: function validateNonce(nonceInState) {
              var savedNonce;

              if (this.saveNoncesInLocalStorage && typeof window['localStorage'] !== 'undefined') {
                savedNonce = localStorage.getItem('nonce');
              } else {
                savedNonce = this._storage.getItem('nonce');
              }

              if (savedNonce !== nonceInState) {
                var _err4 = 'Validating access_token failed, wrong state/nonce.';
                console.error(_err4, savedNonce, nonceInState);
                return false;
              }

              return true;
            }
          }, {
            key: "storeIdToken",
            value: function storeIdToken(idToken) {
              this._storage.setItem('id_token', idToken.idToken);

              this._storage.setItem('id_token_claims_obj', idToken.idTokenClaimsJson);

              this._storage.setItem('id_token_expires_at', '' + idToken.idTokenExpiresAt);

              this._storage.setItem('id_token_stored_at', '' + Date.now());
            }
          }, {
            key: "storeSessionState",
            value: function storeSessionState(sessionState) {
              this._storage.setItem('session_state', sessionState);
            }
          }, {
            key: "getSessionState",
            value: function getSessionState() {
              return this._storage.getItem('session_state');
            }
          }, {
            key: "handleLoginError",
            value: function handleLoginError(options, parts) {
              if (options.onLoginError) {
                options.onLoginError(parts);
              }

              if (this.clearHashAfterLogin && !options.preventClearHashAfterLogin) {
                location.hash = '';
              }
            }
            /**
             * @ignore
             */

          }, {
            key: "processIdToken",
            value: function processIdToken(idToken, accessToken) {
              var _this30 = this;

              var skipNonceCheck = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
              var tokenParts = idToken.split('.');
              var headerBase64 = this.padBase64(tokenParts[0]);
              var headerJson = b64DecodeUnicode(headerBase64);
              var header = JSON.parse(headerJson);
              var claimsBase64 = this.padBase64(tokenParts[1]);
              var claimsJson = b64DecodeUnicode(claimsBase64);
              var claims = JSON.parse(claimsJson);
              var savedNonce;

              if (this.saveNoncesInLocalStorage && typeof window['localStorage'] !== 'undefined') {
                savedNonce = localStorage.getItem('nonce');
              } else {
                savedNonce = this._storage.getItem('nonce');
              }

              if (Array.isArray(claims.aud)) {
                if (claims.aud.every(function (v) {
                  return v !== _this30.clientId;
                })) {
                  var _err5 = 'Wrong audience: ' + claims.aud.join(',');

                  this.logger.warn(_err5);
                  return Promise.reject(_err5);
                }
              } else {
                if (claims.aud !== this.clientId) {
                  var _err6 = 'Wrong audience: ' + claims.aud;

                  this.logger.warn(_err6);
                  return Promise.reject(_err6);
                }
              }

              if (!claims.sub) {
                var _err7 = 'No sub claim in id_token';
                this.logger.warn(_err7);
                return Promise.reject(_err7);
              }
              /* For now, we only check whether the sub against
               * silentRefreshSubject when sessionChecksEnabled is on
               * We will reconsider in a later version to do this
               * in every other case too.
               */


              if (this.sessionChecksEnabled && this.silentRefreshSubject && this.silentRefreshSubject !== claims['sub']) {
                var _err8 = 'After refreshing, we got an id_token for another user (sub). ' + "Expected sub: ".concat(this.silentRefreshSubject, ", received sub: ").concat(claims['sub']);

                this.logger.warn(_err8);
                return Promise.reject(_err8);
              }

              if (!claims.iat) {
                var _err9 = 'No iat claim in id_token';
                this.logger.warn(_err9);
                return Promise.reject(_err9);
              }

              if (!this.skipIssuerCheck && claims.iss !== this.issuer) {
                var _err10 = 'Wrong issuer: ' + claims.iss;

                this.logger.warn(_err10);
                return Promise.reject(_err10);
              }

              if (!skipNonceCheck && claims.nonce !== savedNonce) {
                var _err11 = 'Wrong nonce: ' + claims.nonce;

                this.logger.warn(_err11);
                return Promise.reject(_err11);
              } // at_hash is not applicable to authorization code flow
              // addressing https://github.com/manfredsteyer/angular-oauth2-oidc/issues/661
              // i.e. Based on spec the at_hash check is only true for implicit code flow on Ping Federate
              // https://www.pingidentity.com/developer/en/resources/openid-connect-developers-guide.html


              if (this.hasOwnProperty('responseType') && (this.responseType === 'code' || this.responseType === 'id_token')) {
                this.disableAtHashCheck = true;
              }

              if (!this.disableAtHashCheck && this.requestAccessToken && !claims['at_hash']) {
                var _err12 = 'An at_hash is needed!';
                this.logger.warn(_err12);
                return Promise.reject(_err12);
              }

              var now = Date.now();
              var issuedAtMSec = claims.iat * 1000;
              var expiresAtMSec = claims.exp * 1000;
              var clockSkewInMSec = (this.clockSkewInSec || 600) * 1000;

              if (issuedAtMSec - clockSkewInMSec >= now || expiresAtMSec + clockSkewInMSec <= now) {
                var _err13 = 'Token has expired';
                console.error(_err13);
                console.error({
                  now: now,
                  issuedAtMSec: issuedAtMSec,
                  expiresAtMSec: expiresAtMSec
                });
                return Promise.reject(_err13);
              }

              var validationParams = {
                accessToken: accessToken,
                idToken: idToken,
                jwks: this.jwks,
                idTokenClaims: claims,
                idTokenHeader: header,
                loadKeys: function loadKeys() {
                  return _this30.loadJwks();
                }
              };

              if (this.disableAtHashCheck) {
                return this.checkSignature(validationParams).then(function (_) {
                  var result = {
                    idToken: idToken,
                    idTokenClaims: claims,
                    idTokenClaimsJson: claimsJson,
                    idTokenHeader: header,
                    idTokenHeaderJson: headerJson,
                    idTokenExpiresAt: expiresAtMSec
                  };
                  return result;
                });
              }

              return this.checkAtHash(validationParams).then(function (atHashValid) {
                if (!_this30.disableAtHashCheck && _this30.requestAccessToken && !atHashValid) {
                  var _err14 = 'Wrong at_hash';

                  _this30.logger.warn(_err14);

                  return Promise.reject(_err14);
                }

                return _this30.checkSignature(validationParams).then(function (_) {
                  var atHashCheckEnabled = !_this30.disableAtHashCheck;
                  var result = {
                    idToken: idToken,
                    idTokenClaims: claims,
                    idTokenClaimsJson: claimsJson,
                    idTokenHeader: header,
                    idTokenHeaderJson: headerJson,
                    idTokenExpiresAt: expiresAtMSec
                  };

                  if (atHashCheckEnabled) {
                    return _this30.checkAtHash(validationParams).then(function (atHashValid) {
                      if (_this30.requestAccessToken && !atHashValid) {
                        var _err15 = 'Wrong at_hash';

                        _this30.logger.warn(_err15);

                        return Promise.reject(_err15);
                      } else {
                        return result;
                      }
                    });
                  } else {
                    return result;
                  }
                });
              });
            }
            /**
             * Returns the received claims about the user.
             */

          }, {
            key: "getIdentityClaims",
            value: function getIdentityClaims() {
              var claims = this._storage.getItem('id_token_claims_obj');

              if (!claims) {
                return null;
              }

              return JSON.parse(claims);
            }
            /**
             * Returns the granted scopes from the server.
             */

          }, {
            key: "getGrantedScopes",
            value: function getGrantedScopes() {
              var scopes = this._storage.getItem('granted_scopes');

              if (!scopes) {
                return null;
              }

              return JSON.parse(scopes);
            }
            /**
             * Returns the current id_token.
             */

          }, {
            key: "getIdToken",
            value: function getIdToken() {
              return this._storage ? this._storage.getItem('id_token') : null;
            }
          }, {
            key: "padBase64",
            value: function padBase64(base64data) {
              while (base64data.length % 4 !== 0) {
                base64data += '=';
              }

              return base64data;
            }
            /**
             * Returns the current access_token.
             */

          }, {
            key: "getAccessToken",
            value: function getAccessToken() {
              return this._storage ? this._storage.getItem('access_token') : null;
            }
          }, {
            key: "getRefreshToken",
            value: function getRefreshToken() {
              return this._storage ? this._storage.getItem('refresh_token') : null;
            }
            /**
             * Returns the expiration date of the access_token
             * as milliseconds since 1970.
             */

          }, {
            key: "getAccessTokenExpiration",
            value: function getAccessTokenExpiration() {
              if (!this._storage.getItem('expires_at')) {
                return null;
              }

              return parseInt(this._storage.getItem('expires_at'), 10);
            }
          }, {
            key: "getAccessTokenStoredAt",
            value: function getAccessTokenStoredAt() {
              return parseInt(this._storage.getItem('access_token_stored_at'), 10);
            }
          }, {
            key: "getIdTokenStoredAt",
            value: function getIdTokenStoredAt() {
              return parseInt(this._storage.getItem('id_token_stored_at'), 10);
            }
            /**
             * Returns the expiration date of the id_token
             * as milliseconds since 1970.
             */

          }, {
            key: "getIdTokenExpiration",
            value: function getIdTokenExpiration() {
              if (!this._storage.getItem('id_token_expires_at')) {
                return null;
              }

              return parseInt(this._storage.getItem('id_token_expires_at'), 10);
            }
            /**
             * Checkes, whether there is a valid access_token.
             */

          }, {
            key: "hasValidAccessToken",
            value: function hasValidAccessToken() {
              if (this.getAccessToken()) {
                var expiresAt = this._storage.getItem('expires_at');

                var now = new Date();

                if (expiresAt && parseInt(expiresAt, 10) < now.getTime()) {
                  return false;
                }

                return true;
              }

              return false;
            }
            /**
             * Checks whether there is a valid id_token.
             */

          }, {
            key: "hasValidIdToken",
            value: function hasValidIdToken() {
              if (this.getIdToken()) {
                var expiresAt = this._storage.getItem('id_token_expires_at');

                var now = new Date();

                if (expiresAt && parseInt(expiresAt, 10) < now.getTime()) {
                  return false;
                }

                return true;
              }

              return false;
            }
            /**
             * Retrieve a saved custom property of the TokenReponse object. Only if predefined in authconfig.
             */

          }, {
            key: "getCustomTokenResponseProperty",
            value: function getCustomTokenResponseProperty(requestedProperty) {
              return this._storage && this.config.customTokenParameters && this.config.customTokenParameters.indexOf(requestedProperty) >= 0 && this._storage.getItem(requestedProperty) !== null ? JSON.parse(this._storage.getItem(requestedProperty)) : null;
            }
            /**
             * Returns the auth-header that can be used
             * to transmit the access_token to a service
             */

          }, {
            key: "authorizationHeader",
            value: function authorizationHeader() {
              return 'Bearer ' + this.getAccessToken();
            }
          }, {
            key: "logOut",
            value: function logOut() {
              var _this31 = this;

              var customParameters = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
              var state = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
              var noRedirectToLogoutUrl = false;

              if (typeof customParameters === 'boolean') {
                noRedirectToLogoutUrl = customParameters;
                customParameters = {};
              }

              var id_token = this.getIdToken();

              this._storage.removeItem('access_token');

              this._storage.removeItem('id_token');

              this._storage.removeItem('refresh_token');

              if (this.saveNoncesInLocalStorage) {
                localStorage.removeItem('nonce');
                localStorage.removeItem('PKCE_verifier');
              } else {
                this._storage.removeItem('nonce');

                this._storage.removeItem('PKCE_verifier');
              }

              this._storage.removeItem('expires_at');

              this._storage.removeItem('id_token_claims_obj');

              this._storage.removeItem('id_token_expires_at');

              this._storage.removeItem('id_token_stored_at');

              this._storage.removeItem('access_token_stored_at');

              this._storage.removeItem('granted_scopes');

              this._storage.removeItem('session_state');

              if (this.config.customTokenParameters) {
                this.config.customTokenParameters.forEach(function (customParam) {
                  return _this31._storage.removeItem(customParam);
                });
              }

              this.silentRefreshSubject = null;
              this.eventsSubject.next(new OAuthInfoEvent('logout'));

              if (!this.logoutUrl) {
                return;
              }

              if (noRedirectToLogoutUrl) {
                return;
              }

              if (!id_token && !this.postLogoutRedirectUri) {
                return;
              }

              var logoutUrl;

              if (!this.validateUrlForHttps(this.logoutUrl)) {
                throw new Error("logoutUrl  must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS).");
              } // For backward compatibility


              if (this.logoutUrl.indexOf('{{') > -1) {
                logoutUrl = this.logoutUrl.replace(/\{\{id_token\}\}/, id_token).replace(/\{\{client_id\}\}/, this.clientId);
              } else {
                var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();

                if (id_token) {
                  params = params.set('id_token_hint', id_token);
                }

                var postLogoutUrl = this.postLogoutRedirectUri || this.redirectUri;

                if (postLogoutUrl) {
                  params = params.set('post_logout_redirect_uri', postLogoutUrl);

                  if (state) {
                    params = params.set('state', state);
                  }
                }

                for (var key in customParameters) {
                  params = params.set(key, customParameters[key]);
                }

                logoutUrl = this.logoutUrl + (this.logoutUrl.indexOf('?') > -1 ? '&' : '?') + params.toString();
              }

              this.config.openUri(logoutUrl);
            }
            /**
             * @ignore
             */

          }, {
            key: "createAndSaveNonce",
            value: function createAndSaveNonce() {
              var that = this;
              return this.createNonce().then(function (nonce) {
                // Use localStorage for nonce if possible
                // localStorage is the only storage who survives a
                // redirect in ALL browsers (also IE)
                // Otherwiese we'd force teams who have to support
                // IE into using localStorage for everything
                if (that.saveNoncesInLocalStorage && typeof window['localStorage'] !== 'undefined') {
                  localStorage.setItem('nonce', nonce);
                } else {
                  that._storage.setItem('nonce', nonce);
                }

                return nonce;
              });
            }
            /**
             * @ignore
             */

          }, {
            key: "ngOnDestroy",
            value: function ngOnDestroy() {
              this.clearAccessTokenTimer();
              this.clearIdTokenTimer();
              this.removeSilentRefreshEventListener();
              var silentRefreshFrame = this.document.getElementById(this.silentRefreshIFrameName);

              if (silentRefreshFrame) {
                silentRefreshFrame.remove();
              }

              this.stopSessionCheckTimer();
              this.removeSessionCheckEventListener();
              var sessionCheckFrame = this.document.getElementById(this.sessionCheckIFrameName);

              if (sessionCheckFrame) {
                sessionCheckFrame.remove();
              }
            }
          }, {
            key: "createNonce",
            value: function createNonce() {
              var _this32 = this;

              return new Promise(function (resolve) {
                if (_this32.rngUrl) {
                  throw new Error('createNonce with rng-web-api has not been implemented so far');
                }
                /*
                 * This alphabet is from:
                 * https://tools.ietf.org/html/rfc7636#section-4.1
                 *
                 * [A-Z] / [a-z] / [0-9] / "-" / "." / "_" / "~"
                 */


                var unreserved = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
                var size = 45;
                var id = '';
                var crypto = typeof self === 'undefined' ? null : self.crypto || self['msCrypto'];

                if (crypto) {
                  var bytes = new Uint8Array(size);
                  crypto.getRandomValues(bytes); // Needed for IE

                  if (!bytes.map) {
                    bytes.map = Array.prototype.map;
                  }

                  bytes = bytes.map(function (x) {
                    return unreserved.charCodeAt(x % unreserved.length);
                  });
                  id = String.fromCharCode.apply(null, bytes);
                } else {
                  while (0 < size--) {
                    id += unreserved[Math.random() * unreserved.length | 0];
                  }
                }

                resolve(base64UrlEncode(id));
              });
            }
          }, {
            key: "checkAtHash",
            value: function checkAtHash(params) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                  while (1) {
                    switch (_context4.prev = _context4.next) {
                      case 0:
                        if (this.tokenValidationHandler) {
                          _context4.next = 3;
                          break;
                        }

                        this.logger.warn('No tokenValidationHandler configured. Cannot check at_hash.');
                        return _context4.abrupt("return", true);

                      case 3:
                        return _context4.abrupt("return", this.tokenValidationHandler.validateAtHash(params));

                      case 4:
                      case "end":
                        return _context4.stop();
                    }
                  }
                }, _callee4, this);
              }));
            }
          }, {
            key: "checkSignature",
            value: function checkSignature(params) {
              if (!this.tokenValidationHandler) {
                this.logger.warn('No tokenValidationHandler configured. Cannot check signature.');
                return Promise.resolve(null);
              }

              return this.tokenValidationHandler.validateSignature(params);
            }
            /**
             * Start the implicit flow or the code flow,
             * depending on your configuration.
             */

          }, {
            key: "initLoginFlow",
            value: function initLoginFlow() {
              var additionalState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

              if (this.responseType === 'code') {
                return this.initCodeFlow(additionalState, params);
              } else {
                return this.initImplicitFlow(additionalState, params);
              }
            }
            /**
             * Starts the authorization code flow and redirects to user to
             * the auth servers login url.
             */

          }, {
            key: "initCodeFlow",
            value: function initCodeFlow() {
              var _this33 = this;

              var additionalState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

              if (this.loginUrl !== '') {
                this.initCodeFlowInternal(additionalState, params);
              } else {
                this.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                  return e.type === 'discovery_document_loaded';
                })).subscribe(function (_) {
                  return _this33.initCodeFlowInternal(additionalState, params);
                });
              }
            }
          }, {
            key: "initCodeFlowInternal",
            value: function initCodeFlowInternal() {
              var additionalState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
              var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

              if (!this.validateUrlForHttps(this.loginUrl)) {
                throw new Error("loginUrl  must use HTTPS (with TLS), or config value for property 'requireHttps' must be set to 'false' and allow HTTP (without TLS).");
              }

              this.createLoginUrl(additionalState, '', null, false, params).then(this.config.openUri)["catch"](function (error) {
                console.error('Error in initAuthorizationCodeFlow');
                console.error(error);
              });
            }
          }, {
            key: "createChallangeVerifierPairForPKCE",
            value: function createChallangeVerifierPairForPKCE() {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                var verifier, challengeRaw, challenge;
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        if (this.crypto) {
                          _context5.next = 2;
                          break;
                        }

                        throw new Error('PKCE support for code flow needs a CryptoHander. Did you import the OAuthModule using forRoot() ?');

                      case 2:
                        _context5.next = 4;
                        return this.createNonce();

                      case 4:
                        verifier = _context5.sent;
                        _context5.next = 7;
                        return this.crypto.calcHash(verifier, 'sha-256');

                      case 7:
                        challengeRaw = _context5.sent;
                        challenge = base64UrlEncode(challengeRaw);
                        return _context5.abrupt("return", [challenge, verifier]);

                      case 10:
                      case "end":
                        return _context5.stop();
                    }
                  }
                }, _callee5, this);
              }));
            }
          }, {
            key: "extractRecognizedCustomParameters",
            value: function extractRecognizedCustomParameters(tokenResponse) {
              var foundParameters = new Map();

              if (!this.config.customTokenParameters) {
                return foundParameters;
              }

              this.config.customTokenParameters.forEach(function (recognizedParameter) {
                if (tokenResponse[recognizedParameter]) {
                  foundParameters.set(recognizedParameter, JSON.stringify(tokenResponse[recognizedParameter]));
                }
              });
              return foundParameters;
            }
            /**
             * Revokes the auth token to secure the vulnarability
             * of the token issued allowing the authorization server to clean
             * up any security credentials associated with the authorization
             */

          }, {
            key: "revokeTokenAndLogout",
            value: function revokeTokenAndLogout() {
              var _this34 = this;

              var customParameters = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
              var ignoreCorsIssues = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
              var revokeEndpoint = this.revocationEndpoint;
              var accessToken = this.getAccessToken();
              var refreshToken = this.getRefreshToken();

              if (!accessToken) {
                return;
              }

              var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]();
              var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]().set('Content-Type', 'application/x-www-form-urlencoded');

              if (this.useHttpBasicAuth) {
                var header = btoa("".concat(this.clientId, ":").concat(this.dummyClientSecret));
                headers = headers.set('Authorization', 'Basic ' + header);
              }

              if (!this.useHttpBasicAuth) {
                params = params.set('client_id', this.clientId);
              }

              if (!this.useHttpBasicAuth && this.dummyClientSecret) {
                params = params.set('client_secret', this.dummyClientSecret);
              }

              if (this.customQueryParams) {
                var _iterator7 = _createForOfIteratorHelper(Object.getOwnPropertyNames(this.customQueryParams)),
                    _step7;

                try {
                  for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                    var key = _step7.value;
                    params = params.set(key, this.customQueryParams[key]);
                  }
                } catch (err) {
                  _iterator7.e(err);
                } finally {
                  _iterator7.f();
                }
              }

              return new Promise(function (resolve, reject) {
                var revokeAccessToken;
                var revokeRefreshToken;

                if (accessToken) {
                  var revokationParams = params.set('token', accessToken).set('token_type_hint', 'access_token');
                  revokeAccessToken = _this34.http.post(revokeEndpoint, revokationParams, {
                    headers: headers
                  });
                } else {
                  revokeAccessToken = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
                }

                if (refreshToken) {
                  var _revokationParams = params.set('token', refreshToken).set('token_type_hint', 'refresh_token');

                  revokeRefreshToken = _this34.http.post(revokeEndpoint, _revokationParams, {
                    headers: headers
                  });
                } else {
                  revokeRefreshToken = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
                }

                if (ignoreCorsIssues) {
                  revokeAccessToken = revokeAccessToken.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) {
                    if (err.status === 0) {
                      return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
                    }

                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(err);
                  }));
                  revokeRefreshToken = revokeRefreshToken.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) {
                    if (err.status === 0) {
                      return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
                    }

                    return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(err);
                  }));
                }

                Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["combineLatest"])([revokeAccessToken, revokeRefreshToken]).subscribe(function (res) {
                  _this34.logOut(customParameters);

                  resolve(res);

                  _this34.logger.info('Token successfully revoked');
                }, function (err) {
                  _this34.logger.error('Error revoking token', err);

                  _this34.eventsSubject.next(new OAuthErrorEvent('token_revoke_error', err));

                  reject(err);
                });
              });
            }
          }]);

          return OAuthService;
        }(AuthConfig);

        OAuthService.ɵfac = function OAuthService_Factory(t) {
          return new (t || OAuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](OAuthStorage, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](ValidationHandler, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](AuthConfig, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](UrlHelperService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](OAuthLogger), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](HashHandler, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]));
        };

        OAuthService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
          token: OAuthService,
          factory: OAuthService.ɵfac
        });

        OAuthService.ctorParameters = function () {
          return [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
          }, {
            type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
          }, {
            type: OAuthStorage,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }]
          }, {
            type: ValidationHandler,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }]
          }, {
            type: AuthConfig,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }]
          }, {
            type: UrlHelperService
          }, {
            type: OAuthLogger
          }, {
            type: HashHandler,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }]
          }, {
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]]
            }]
          }];
        };
        /*@__PURE__*/


        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](OAuthService, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
          }], function () {
            return [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
            }, {
              type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
            }, {
              type: OAuthStorage,
              decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
              }]
            }, {
              type: ValidationHandler,
              decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
              }]
            }, {
              type: AuthConfig,
              decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
              }]
            }, {
              type: UrlHelperService
            }, {
              type: OAuthLogger
            }, {
              type: HashHandler,
              decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
              }]
            }, {
              type: undefined,
              decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
                args: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"]]
              }]
            }];
          }, null);
        })();

        var OAuthModuleConfig = function OAuthModuleConfig() {
          _classCallCheck(this, OAuthModuleConfig);
        };

        var OAuthResourceServerConfig = function OAuthResourceServerConfig() {
          _classCallCheck(this, OAuthResourceServerConfig);
        };

        var OAuthResourceServerErrorHandler = function OAuthResourceServerErrorHandler() {
          _classCallCheck(this, OAuthResourceServerErrorHandler);
        };

        var OAuthNoopResourceServerErrorHandler = /*#__PURE__*/function () {
          function OAuthNoopResourceServerErrorHandler() {
            _classCallCheck(this, OAuthNoopResourceServerErrorHandler);
          }

          _createClass(OAuthNoopResourceServerErrorHandler, [{
            key: "handleError",
            value: function handleError(err) {
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["throwError"])(err);
            }
          }]);

          return OAuthNoopResourceServerErrorHandler;
        }();

        var DefaultOAuthInterceptor = /*#__PURE__*/function () {
          function DefaultOAuthInterceptor(authStorage, oAuthService, errorHandler, moduleConfig) {
            _classCallCheck(this, DefaultOAuthInterceptor);

            this.authStorage = authStorage;
            this.oAuthService = oAuthService;
            this.errorHandler = errorHandler;
            this.moduleConfig = moduleConfig;
          }

          _createClass(DefaultOAuthInterceptor, [{
            key: "checkUrl",
            value: function checkUrl(url) {
              if (this.moduleConfig.resourceServer.customUrlValidation) {
                return this.moduleConfig.resourceServer.customUrlValidation(url);
              }

              if (this.moduleConfig.resourceServer.allowedUrls) {
                return !!this.moduleConfig.resourceServer.allowedUrls.find(function (u) {
                  return url.startsWith(u);
                });
              }

              return true;
            }
          }, {
            key: "intercept",
            value: function intercept(req, next) {
              var _this35 = this;

              var url = req.url.toLowerCase();

              if (!this.moduleConfig || !this.moduleConfig.resourceServer || !this.checkUrl(url)) {
                return next.handle(req);
              }

              var sendAccessToken = this.moduleConfig.resourceServer.sendAccessToken;

              if (!sendAccessToken) {
                return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) {
                  return _this35.errorHandler.handleError(err);
                }));
              }

              return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["merge"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(this.oAuthService.getAccessToken()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (token) {
                return token ? true : false;
              })), this.oAuthService.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (e) {
                return e.type === 'token_received';
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["timeout"])(this.oAuthService.waitForTokenInMsec || 0), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (_) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["of"])(null);
              }), // timeout is not an error
              Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (_) {
                return _this35.oAuthService.getAccessToken();
              }))).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["mergeMap"])(function (token) {
                if (token) {
                  var header = 'Bearer ' + token;
                  var headers = req.headers.set('Authorization', header);
                  req = req.clone({
                    headers: headers
                  });
                }

                return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (err) {
                  return _this35.errorHandler.handleError(err);
                }));
              }));
            }
          }]);

          return DefaultOAuthInterceptor;
        }();

        DefaultOAuthInterceptor.ɵfac = function DefaultOAuthInterceptor_Factory(t) {
          return new (t || DefaultOAuthInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](OAuthStorage), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](OAuthService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](OAuthResourceServerErrorHandler), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](OAuthModuleConfig, 8));
        };

        DefaultOAuthInterceptor.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
          token: DefaultOAuthInterceptor,
          factory: DefaultOAuthInterceptor.ɵfac
        });

        DefaultOAuthInterceptor.ctorParameters = function () {
          return [{
            type: OAuthStorage
          }, {
            type: OAuthService
          }, {
            type: OAuthResourceServerErrorHandler
          }, {
            type: OAuthModuleConfig,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }]
          }];
        };
        /*@__PURE__*/


        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DefaultOAuthInterceptor, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
          }], function () {
            return [{
              type: OAuthStorage
            }, {
              type: OAuthService
            }, {
              type: OAuthResourceServerErrorHandler
            }, {
              type: OAuthModuleConfig,
              decorators: [{
                type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
              }]
            }];
          }, null);
        })();
        /**
         * A validation handler that isn't validating nothing.
         * Can be used to skip validation (at your own risk).
         */


        var NullValidationHandler = /*#__PURE__*/function () {
          function NullValidationHandler() {
            _classCallCheck(this, NullValidationHandler);
          }

          _createClass(NullValidationHandler, [{
            key: "validateSignature",
            value: function validateSignature(validationParams) {
              return Promise.resolve(null);
            }
          }, {
            key: "validateAtHash",
            value: function validateAtHash(validationParams) {
              return Promise.resolve(true);
            }
          }]);

          return NullValidationHandler;
        }();

        function createDefaultLogger() {
          return console;
        }

        function createDefaultStorage() {
          return typeof sessionStorage !== 'undefined' ? sessionStorage : new MemoryStorage();
        }

        var OAuthModule = /*#__PURE__*/function () {
          function OAuthModule() {
            _classCallCheck(this, OAuthModule);
          }

          _createClass(OAuthModule, null, [{
            key: "forRoot",
            value: function forRoot() {
              var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
              var validationHandlerClass = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : NullValidationHandler;
              return {
                ngModule: OAuthModule,
                providers: [OAuthService, UrlHelperService, {
                  provide: OAuthLogger,
                  useFactory: createDefaultLogger
                }, {
                  provide: OAuthStorage,
                  useFactory: createDefaultStorage
                }, {
                  provide: ValidationHandler,
                  useClass: validationHandlerClass
                }, {
                  provide: HashHandler,
                  useClass: DefaultHashHandler
                }, {
                  provide: OAuthResourceServerErrorHandler,
                  useClass: OAuthNoopResourceServerErrorHandler
                }, {
                  provide: OAuthModuleConfig,
                  useValue: config
                }, {
                  provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HTTP_INTERCEPTORS"],
                  useClass: DefaultOAuthInterceptor,
                  multi: true
                }]
              };
            }
          }]);

          return OAuthModule;
        }();

        OAuthModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
          type: OAuthModule
        });
        OAuthModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
          factory: function OAuthModule_Factory(t) {
            return new (t || OAuthModule)();
          },
          imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]]]
        });

        (function () {
          (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](OAuthModule, {
            imports: function imports() {
              return [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]];
            }
          });
        })();
        /*@__PURE__*/


        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](OAuthModule, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
            args: [{
              imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
              declarations: [],
              exports: []
            }]
          }], null, null);
        })();

        var err = "PLEASE READ THIS CAREFULLY:\n\nBeginning with angular-oauth2-oidc version 9, the JwksValidationHandler\nhas been moved to an library of its own. If you need it for implementing\nOAuth2/OIDC **implicit flow**, please install it using npm:\n\n  npm i angular-oauth2-oidc-jwks --save\n\nAfter that, you can import it into your application:\n\n  import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';\n\nPlease note, that this dependency is not needed for the **code flow**,\nwhich is nowadays the **recommented** one for single page applications.\nThis also results in smaller bundle sizes.\n";
        /**
         * This is just a dummy of the JwksValidationHandler
         * telling the users that the real one has been moved
         * to an library of its own, namely angular-oauth2-oidc-utils
         */

        var JwksValidationHandler = /*#__PURE__*/function (_NullValidationHandle) {
          _inherits(JwksValidationHandler, _NullValidationHandle);

          var _super5 = _createSuper(JwksValidationHandler);

          function JwksValidationHandler() {
            var _this36;

            _classCallCheck(this, JwksValidationHandler);

            _this36 = _super5.call(this);
            console.error(err);
            return _this36;
          }

          return JwksValidationHandler;
        }(NullValidationHandler);

        var AUTH_CONFIG = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('AUTH_CONFIG');
        /**
         * Generated bundle index. Do not edit.
         */
        //# sourceMappingURL=angular-oauth2-oidc.js.map

        /* WEBPACK VAR INJECTION */
      }).call(this, __webpack_require__(
      /*! ./../../../webpack/buildin/harmony-module.js */
      "3UD+")(module));
      /***/
    },

    /***/
    "PDX0":
    /*!****************************************!*\
      !*** (webpack)/buildin/amd-options.js ***!
      \****************************************/

    /*! no static exports found */

    /***/
    function PDX0(module, exports) {
      /* WEBPACK VAR INJECTION */
      (function (__webpack_amd_options__) {
        /* globals __webpack_amd_options__ */
        module.exports = __webpack_amd_options__;
        /* WEBPACK VAR INJECTION */
      }).call(this, {});
      /***/
    },

    /***/
    "UV1U":
    /*!*************************************************************************!*\
      !*** ./src/app/constructor/application-menu/application-menu.module.ts ***!
      \*************************************************************************/

    /*! exports provided: ApplicationMenuModule */

    /***/
    function UV1U(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApplicationMenuModule", function () {
        return ApplicationMenuModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _application_menu_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./application-menu.component */
      "woOp");
      /* harmony import */


      var _application_menu_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./application-menu-routing.module */
      "/fUX");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ng-bootstrap/ng-bootstrap */
      "1kSV");
      /* harmony import */


      var ng_inline_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ng-inline-svg */
      "e8Ap");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");
      /* harmony import */


      var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/snack-bar */
      "dNgK");
      /* harmony import */


      var _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../platform/framework/core/services/toast.service */
      "wV1m");
      /* harmony import */


      var _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../platform/LayoutsComponents/CommonExtensions.module */
      "csDf");
      /* harmony import */


      var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/material/checkbox */
      "bSwM");
      /* harmony import */


      var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/cdk/drag-drop */
      "5+WD");
      /* harmony import */


      var _angular_material_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/material/select */
      "d3UM");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/material/form-field */
      "kmnG");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/material/input */
      "qFsG");
      /* harmony import */


      var _ConstructorComponents_gallery_dialog_gallery_dialog_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ../ConstructorComponents/gallery-dialog/gallery-dialog.module */
      "Iq9u"); //import {GalleryDialogModule} from '../../../modules/gallery-dialog/gallery-dialog.module';


      var ApplicationMenuModule = function ApplicationMenuModule() {
        _classCallCheck(this, ApplicationMenuModule);
      };

      ApplicationMenuModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: ApplicationMenuModule
      });
      ApplicationMenuModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function ApplicationMenuModule_Factory(t) {
          return new (t || ApplicationMenuModule)();
        },
        providers: [_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBar"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBarModule"], _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_9__["ToastService"]],
        imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _application_menu_routing_module__WEBPACK_IMPORTED_MODULE_3__["ApplicationMenuRoutingModule"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__["DragDropModule"], _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_10__["CommonExtensions"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbDropdownModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_11__["MatCheckboxModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbTooltipModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_13__["MatSelectModule"], ng_inline_svg__WEBPACK_IMPORTED_MODULE_6__["InlineSVGModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatFormFieldModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_15__["MatInputModule"], _ConstructorComponents_gallery_dialog_gallery_dialog_module__WEBPACK_IMPORTED_MODULE_16__["GalleryDialogModule"]]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](ApplicationMenuModule, {
          declarations: [_application_menu_component__WEBPACK_IMPORTED_MODULE_2__["ApplicationMenuComponent"]],
          imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _application_menu_routing_module__WEBPACK_IMPORTED_MODULE_3__["ApplicationMenuRoutingModule"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__["DragDropModule"], _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_10__["CommonExtensions"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbDropdownModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_11__["MatCheckboxModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbTooltipModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_13__["MatSelectModule"], ng_inline_svg__WEBPACK_IMPORTED_MODULE_6__["InlineSVGModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatFormFieldModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_15__["MatInputModule"], _ConstructorComponents_gallery_dialog_gallery_dialog_module__WEBPACK_IMPORTED_MODULE_16__["GalleryDialogModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ApplicationMenuModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            providers: [_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBar"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBarModule"], _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_9__["ToastService"]],
            declarations: [_application_menu_component__WEBPACK_IMPORTED_MODULE_2__["ApplicationMenuComponent"]],
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _application_menu_routing_module__WEBPACK_IMPORTED_MODULE_3__["ApplicationMenuRoutingModule"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_12__["DragDropModule"], _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_10__["CommonExtensions"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbDropdownModule"], _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_11__["MatCheckboxModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbTooltipModule"], _angular_material_select__WEBPACK_IMPORTED_MODULE_13__["MatSelectModule"], ng_inline_svg__WEBPACK_IMPORTED_MODULE_6__["InlineSVGModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__["MatSnackBarModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__["MatFormFieldModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_15__["MatInputModule"], _ConstructorComponents_gallery_dialog_gallery_dialog_module__WEBPACK_IMPORTED_MODULE_16__["GalleryDialogModule"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "woOp":
    /*!****************************************************************************!*\
      !*** ./src/app/constructor/application-menu/application-menu.component.ts ***!
      \****************************************************************************/

    /*! exports provided: ApplicationMenuComponent */

    /***/
    function woOp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApplicationMenuComponent", function () {
        return ApplicationMenuComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/cdk/drag-drop */
      "5+WD");
      /* harmony import */


      var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/material/dialog */
      "0IaG");
      /* harmony import */


      var _ConstructorComponents_gallery_dialog_gallery_dialog_objects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../ConstructorComponents/gallery-dialog/gallery-dialog.objects */
      "3n/0");
      /* harmony import */


      var _ConstructorComponents_gallery_dialog_gallery_dialog_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../ConstructorComponents/gallery-dialog/gallery-dialog.component */
      "XVAz");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ng-bootstrap/ng-bootstrap */
      "1kSV");
      /* harmony import */


      var _ConstructorComponents_gallery_dialog_services_gallery_images_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../ConstructorComponents/gallery-dialog/services/gallery-images.service */
      "4VEp");
      /* harmony import */


      var _services_translation_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../services/translation.service */
      "ty2H");
      /* harmony import */


      var _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../../platform/framework/core/services/toast.service */
      "wV1m");
      /* harmony import */


      var _ConstructorComponents_subheader_services_subheader_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ../ConstructorComponents/subheader/_services/subheader.service */
      "0dlt");
      /* harmony import */


      var _services_application_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ../../services/application.service */
      "AQhQ");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var ng_inline_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! ng-inline-svg */
      "e8Ap");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! @angular/material/form-field */
      "kmnG");
      /* harmony import */


      var _angular_material_select__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! @angular/material/select */
      "d3UM");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _angular_material_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
      /*! @angular/material/core */
      "FKr1");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      function ApplicationMenuComponent_ng_container_2_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        }
      }

      function ApplicationMenuComponent_span_13_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 20);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, "CONSTRUCTOR.COLORS.SAVE_TO_STORE"));
        }
      }

      function ApplicationMenuComponent_div_32_div_1_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 23);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, "CONSTRUCTOR.APP_MENU.LIST_EMPTY"), " ");
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_4_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 41);
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_a_16_Template(rf, ctx) {
        if (rf & 1) {
          var _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 42);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_a_16_Template_a_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r15);

            var item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

            var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);

            return ctx_r13.openEditor(item_r6);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 43);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "span", 44);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("inlineSVG", "./assets/media/svg/icons/Design/Edit.svg");
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_a_17_Template(rf, ctx) {
        if (rf & 1) {
          var _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 45);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_a_17_Template_a_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r18);

            var item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

            return item_r6.show_confirm = true;
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 46);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "span", 44);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("inlineSVG", "./assets/media/svg/icons/Home/Trash.svg");
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_18_Template(rf, ctx) {
        if (rf & 1) {
          var _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 47);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "a", 48);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_div_18_Template_a_click_3_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r21);

            var item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

            return item_r6.show_confirm = false;
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](5, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "a", 49);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_div_18_Template_a_click_6_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r21);

            var ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            var item_r6 = ctx_r23.$implicit;
            var item_index_r7 = ctx_r23.index;

            var ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);

            return ctx_r22.removeItem(item_r6, item_index_r7);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 3, "GENERAL.LANGUAGES.ARE_YOU_SURE"), " ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](5, 5, "GENERAL.LANGUAGES.CANCEL"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 7, "GENERAL.LANGUAGES.CONFIRM"));
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_19_div_3_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 57);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span", 65);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "*");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "input", 66);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_div_3_Template_input_ngModelChange_5_listener($event) {
            var lang_item_r28 = ctx.$implicit;
            return lang_item_r28.language_value = $event;
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var lang_item_r28 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", lang_item_r28.language_name, " (", lang_item_r28.language_code, ") ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", lang_item_r28.language_value);
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_19_mat_option_9_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 67);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var action_r30 = ctx.$implicit;

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", action_r30.target);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 3, action_r30.text), " ", action_r30.name, "");
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_19_img_16_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "img", 68);
        }

        if (rf & 2) {
          var ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate3"]("src", "", ctx_r26.platform_url, "", ctx_r26.resources_dir, "", ctx_r26.object_in_editor.image, "", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_19_a_17_Template(rf, ctx) {
        if (rf & 1) {
          var _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 69);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_a_17_Template_a_click_0_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r32);

            var ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](5);

            return ctx_r31.clearImage();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 70);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template(rf, ctx) {
        if (rf & 1) {
          var _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 50);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 51);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ApplicationMenuComponent_div_32_div_2_div_1_div_19_div_3_Template, 6, 3, "div", 53);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 52);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-form-field", 54);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "mat-select", 55);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("valueChange", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template_mat_select_valueChange_7_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r34);

            var ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](4);

            return ctx_r33.object_in_editor.action = $event;
          })("selectionChange", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template_mat_select_selectionChange_7_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r34);

            var ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](4);

            return ctx_r35.actionChange($event.value);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, ApplicationMenuComponent_div_32_div_2_div_1_div_19_mat_option_9_Template, 3, 5, "mat-option", 56);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 57);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](14, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 58);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, ApplicationMenuComponent_div_32_div_2_div_1_div_19_img_16_Template, 1, 3, "img", 59);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, ApplicationMenuComponent_div_32_div_2_div_1_div_19_a_17_Template, 2, 0, "a", 60);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "button", 61);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template_button_click_18_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r34);

            var ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](4);

            return ctx_r36.openGalleryDialog();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](20, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 62);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "a", 63);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template_a_click_22_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r34);

            var ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            var item_r6 = ctx_r38.$implicit;
            var item_index_r7 = ctx_r38.index;

            var ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);

            return ctx_r37.applyChanges(item_r6, item_index_r7);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](24, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "a", 64);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template_a_click_25_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r34);

            var item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;

            return item_r6.show_editor = false;
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](27, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r12.object_in_editor.name_translations);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("placeholder", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 10, "CONSTRUCTOR.APP_MENU.ACTION"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r12.object_in_editor.action);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r12.actions);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](14, 12, "CONSTRUCTOR.APP_MENU.ICON"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r12.object_in_editor.image && ctx_r12.object_in_editor.image != "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r12.object_in_editor.image && ctx_r12.object_in_editor.image != "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](20, 14, "CONSTRUCTOR.APP_MENU.ICON_CHANGE"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](24, 16, "GENERAL.LANGUAGES.APPLY"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](27, 18, "GENERAL.LANGUAGES.CANCEL"));
        }
      }

      function ApplicationMenuComponent_div_32_div_2_div_1_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 26);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 27);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 28);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "i", 29);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ApplicationMenuComponent_div_32_div_2_div_1_div_4_Template, 1, 0, "div", 30);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 31);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "div", 32);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 33);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "p", 34);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span", 35);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](12, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "i", 36);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](15, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, ApplicationMenuComponent_div_32_div_2_div_1_a_16_Template, 3, 1, "a", 37);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](17, ApplicationMenuComponent_div_32_div_2_div_1_a_17_Template, 3, 1, "a", 38);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, ApplicationMenuComponent_div_32_div_2_div_1_div_18_Template, 9, 9, "div", 39);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](19, ApplicationMenuComponent_div_32_div_2_div_1_div_19_Template, 28, 20, "div", 40);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var item_r6 = ctx.$implicit;

          var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleMapInterpolate3"]("background-image: url('", ctx_r5.platform_url, "", ctx_r5.resources_dir, "", item_r6.image, "')");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r6.name);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](12, 13, "CONSTRUCTOR.APP_MENU.ACTION"), " ");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](15, 15, item_r6.action_text), " ", item_r6.action_name, "");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !item_r6.show_editor && !item_r6.show_confirm);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !item_r6.show_editor && !item_r6.show_confirm);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r6.show_confirm && !item_r6.show_editor);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r6.show_editor && !item_r6.show_confirm);
        }
      }

      function ApplicationMenuComponent_div_32_div_2_Template(rf, ctx) {
        if (rf & 1) {
          var _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 24);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("cdkDropListDropped", function ApplicationMenuComponent_div_32_div_2_Template_div_cdkDropListDropped_0_listener($event) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r42);

            var ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

            return ctx_r41.drop($event);
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ApplicationMenuComponent_div_32_div_2_div_1_Template, 20, 17, "div", 25);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r4.menu);
        }
      }

      function ApplicationMenuComponent_div_32_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ApplicationMenuComponent_div_32_div_1_Template, 3, 3, "div", 21);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ApplicationMenuComponent_div_32_div_2_Template, 2, 1, "div", 22);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r2.menu.length == 0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r2.menu.length > 0);
        }
      }

      var ApplicationMenuComponent = /*#__PURE__*/function () {
        function ApplicationMenuComponent(route, modalService, dialog, galleryImagesService, ref, translationService, router, toastService, activateRoute, subheader, applicationService) {
          _classCallCheck(this, ApplicationMenuComponent);

          this.route = route;
          this.modalService = modalService;
          this.dialog = dialog;
          this.galleryImagesService = galleryImagesService;
          this.ref = ref;
          this.translationService = translationService;
          this.router = router;
          this.toastService = toastService;
          this.activateRoute = activateRoute;
          this.subheader = subheader;
          this.applicationService = applicationService;
          this.was_changed = false;
          this.was_loaded = false;
          this.menu = [];
          this.languages = [];
          this.actions = [];
          this.default_language = "";
          this.resources_dir = "";
          this.platform_url = "";
        }

        _createClass(ApplicationMenuComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this37 = this;

            this.platform_url = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl;
            var gallery = localStorage.getItem('open_gallery');

            if (gallery != null) {
              localStorage.removeItem('open_gallery');
              this.openGalleryDialog();
            }

            this.galleryImagesService.dataFound.subscribe(function (data) {
              console.log('dataFound', data);
            });
            this.app_id = Number(this.router.url.match(/constructor\/(\d+)/)[1]);
            setTimeout(function () {
              _this37.subheader.setTitle('CONSTRUCTOR.APP_MENU.TITLE');
            }, 1);
            this.isLoading$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
              observer.next(true);

              _this37.applicationService.getApplicationMenu(_this37.app_id).then(function (data) {
                _this37.menu = [];
                _this37.languages = data.languages;
                _this37.menu = data.menu;
                _this37.resources_dir = data.resources_dir;
                _this37.actions = data.actions;
                _this37.default_language = data.default_language;
                _this37.was_loaded = true;
                observer.next(false);
              })["finally"](function () {//observer.next(false);
              });
            });
            console.log('queryParams', this.route.snapshot.queryParams);

            if (this.route.snapshot.queryParams && this.route.snapshot.queryParams['test'] != null) {
              this.galleryImagesService.onDataFound('OK CHECK NOW');
            }
          }
        }, {
          key: "addItem",
          value: function addItem() {
            var _this38 = this;

            var item = {
              name: "Menu",
              name_translations: [],
              action_text: "",
              action_target: "",
              action_name: "",
              image: "",
              target: "Page1",
              show_confirm: false,
              show_editor: false
            };
            var name_translations = [];
            this.languages.forEach(function (lng_item) {
              if (lng_item.code == _this38.default_language) item.name = "Name";
              name_translations.push({
                language_code: lng_item.code,
                language_name: lng_item.name,
                language_value: "Name"
              });
            });
            item.name_translations = name_translations;
            this.menu.unshift(item);
            this.was_changed = true;
          } //if actionb was changed - change object

        }, {
          key: "actionChange",
          value: function actionChange(ev) {
            var _this39 = this;

            console.log(ev);
            this.actions.forEach(function (action) {
              if (action.target == ev) {
                _this39.object_in_editor.action_text = action.text;
                _this39.object_in_editor.action_target = action.target;
                _this39.object_in_editor.action_name = action.name;
              }
            });
          } //drop event

        }, {
          key: "drop",
          value: function drop(event) {
            Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__["moveItemInArray"])(this.menu, event.previousIndex, event.currentIndex);
            this.was_changed = true;
          }
        }, {
          key: "save",
          value: function save() {
            var _this40 = this;

            this.isLoading$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
              observer.next(true);

              _this40.applicationService.setApplicationMenu(_this40.app_id, _this40.menu).then(function (response) {
                if (response.is_error) {
                  _this40.toastService.showsToastBar(_this40.translationService.translatePhrase('GENERAL.LANGUAGES.CHANGES_NOT_SAVED'), 'danger');
                } else {
                  _this40.toastService.showsToastBar(_this40.translationService.translatePhrase('GENERAL.LANGUAGES.CHANGES_SAVED'), 'success');
                }

                observer.next(false);
                _this40.was_changed = false;
              })["finally"](function () {//observer.next(false);
              });
            });
          }
        }, {
          key: "cancel",
          value: function cancel() {
            var _this41 = this;

            this.isLoading$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
              observer.next(true);

              _this41.applicationService.getApplicationMenu(_this41.app_id).then(function (data) {
                _this41.menu = [];
                _this41.languages = data.languages;
                _this41.menu = data.menu;
                _this41.resources_dir = data.resources_dir;
                _this41.actions = data.actions;
                _this41.default_language = data.default_language;
                _this41.was_loaded = true;
                observer.next(false);
              })["finally"](function () {//observer.next(false);
              });
            });
          }
          /**
           * Open menu dialog
           * @param item menu item
           */

        }, {
          key: "openEditor",
          value: function openEditor(item) {
            console.log(item);
            this.menu.forEach(function (element) {
              element.show_editor = false;
            });
            item.show_editor = true;
            item.show_confirm = false;
            this.object_in_editor = Object.assign({}, item);
          }
          /**
           * Apply menu changes in menu array
           * @param item item,
           * @param item_index item index in menu array
           */

        }, {
          key: "applyChanges",
          value: function applyChanges(item, item_index) {
            var _this42 = this;

            this.object_in_editor.name_translations.forEach(function (element) {
              if (element.language_code == _this42.default_language) _this42.object_in_editor.name = element.language_value;
            });
            this.object_in_editor.show_editor = false;
            this.object_in_editor.show_confirm = false;
            this.menu[item_index] = Object.assign({}, this.object_in_editor);
            this.ref.detectChanges();
            this.was_changed = true;
            console.log(this.menu[item_index]);
          }
          /**
           * Remove item menu
           * @param item item
           * @param item_index item index
           */

        }, {
          key: "removeItem",
          value: function removeItem(item, item_index) {
            this.menu.splice(item_index, 1);
            this.was_changed = true;
            this.ref.detectChanges();
          }
        }, {
          key: "openGalleryDialog",
          value: function openGalleryDialog() {
            var _this43 = this;

            var dialogConfig = new _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialogConfig"]();
            dialogConfig.disableClose = false;
            dialogConfig.autoFocus = true;
            dialogConfig.width = '1000px';
            dialogConfig.data = new _ConstructorComponents_gallery_dialog_gallery_dialog_objects__WEBPACK_IMPORTED_MODULE_4__["GalleryDialog"](this.resources_dir, false, '.jpg,.png,.jpeg,.ico,.svg', this.resources_dir);
            var dialogRef = this.dialog.open(_ConstructorComponents_gallery_dialog_gallery_dialog_component__WEBPACK_IMPORTED_MODULE_5__["GalleryDialogComponent"], dialogConfig);
            dialogRef.afterClosed().subscribe(function (result) {
              if (result) {
                // This will Return Selected Images
                _this43.object_in_editor.image = result.fileName;
                console.log('SELECTED IMAGES', result);

                _this43.ref.detectChanges();
              }
            });
          }
        }, {
          key: "clearImage",
          value: function clearImage() {
            this.object_in_editor.image = "";
          }
        }]);

        return ApplicationMenuComponent;
      }();

      ApplicationMenuComponent.ɵfac = function ApplicationMenuComponent_Factory(t) {
        return new (t || ApplicationMenuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ConstructorComponents_gallery_dialog_services_gallery_images_service__WEBPACK_IMPORTED_MODULE_9__["GalleryImagesService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_translation_service__WEBPACK_IMPORTED_MODULE_10__["TranslationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_11__["ToastService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ConstructorComponents_subheader_services_subheader_service__WEBPACK_IMPORTED_MODULE_12__["SubheaderService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_application_service__WEBPACK_IMPORTED_MODULE_13__["ApplicationService"]));
      };

      ApplicationMenuComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: ApplicationMenuComponent,
        selectors: [["app-application-menu"]],
        decls: 33,
        vars: 23,
        consts: [[1, "card", "card-custom", "gutter-b"], [4, "ngIf"], [1, "card-header", "py-3"], [1, "card-title", "align-items-start", "flex-column"], [1, "card-label", "font-weight-bolder", "text-dark"], [1, "text-muted", "font-weight-bold", "font-size-sm", "mt-1"], [1, "card-toolbar"], ["class", "label label-warning label-pill label-inline mr-2", 4, "ngIf"], ["type", "submit", 1, "btn", "btn-success", "mr-2", 3, "click"], ["type", "reset", 1, "btn", "btn-secondary", "mr-2", 3, "click"], [1, "form", "card-body", "mt-2"], ["role", "alert", 1, "alert", "alert-custom", "alert-light-primary", "fade", "show", "mb-5", "p-1", "pl-3"], [1, "alert-icon"], [1, "flaticon-warning"], [1, "alert-text"], [1, "gutter-b"], ["type", "button", 1, "btn", "btn-primary", "btn-sm", 3, "click"], [1, "fas", "fa-plus"], [1, "progress", "progress-modal"], ["role", "progressbar", "aria-valuenow", "100", "aria-valuemin", "0", "aria-valuemax", "100", 1, "progress-bar", "progress-bar-striped", "progress-bar-animated", "bg-primary", 2, "width", "100%"], [1, "label", "label-warning", "label-pill", "label-inline", "mr-2"], ["class", "font-size-lg font-dark font-bold", 4, "ngIf"], ["cdkDropList", "", "class", "menu-list", 3, "cdkDropListDropped", 4, "ngIf"], [1, "font-size-lg", "font-dark", "font-bold"], ["cdkDropList", "", 1, "menu-list", 3, "cdkDropListDropped"], ["cdkDrag", "", "class", "menu_item", 4, "ngFor", "ngForOf"], ["cdkDrag", "", 1, "menu_item"], [1, "menu-box", "d-flex", "flex-wrap", "align-items-center"], ["cdkDragHandle", "", 1, "symbol", "symbol-25", "mr-2"], [1, "fas", "fa-arrows-alt"], ["class", "menu-custom-placeholder", 4, "cdkDragPlaceholder"], [1, "symbol", "symbol-50", "mr-2"], [1, "symbol-label"], [1, "d-flex", "flex-column", "flex-grow-1", "my-lg-0", "my-2", "mr-2"], [1, "text-dark-75", "font-weight-bold", "font-size-lg", "mb-1"], [1, "text-muted", "font-weight-bold"], [1, "flaticon2-arrow"], ["class", "btn btn-icon btn-light btn-sm mr-1", 3, "click", 4, "ngIf"], ["class", "btn btn-icon btn-light btn-sm", 3, "click", 4, "ngIf"], ["class", "pl-1 pt-2 ml-3", 4, "ngIf"], ["class", "pl-1 pt-2 pb-1", 4, "ngIf"], [1, "menu-custom-placeholder"], [1, "btn", "btn-icon", "btn-light", "btn-sm", "mr-1", 3, "click"], [1, "svg-icon", "svg-icon-primary"], ["cacheSVG", "true", 1, "svg-icon", "svg-icon-md", 3, "inlineSVG"], [1, "btn", "btn-icon", "btn-light", "btn-sm", 3, "click"], [1, "svg-icon", "svg-icon-danger"], [1, "pl-1", "pt-2", "ml-3"], [1, "btn", "btn-text-dark", "btn-hover-light-dark", "btn-sm", "font-weight-bold", "mr-2", 3, "click"], [1, "btn", "btn-text-danger", "btn-hover-light-danger", "btn-sm", "font-weight-bold", "mr-2", 3, "click"], [1, "pl-1", "pt-2", "pb-1"], [1, "row"], [1, "col-sm-4"], ["class", "form-group", 4, "ngFor", "ngForOf"], ["appearance", "fill"], ["matNativeControl", "", "name", "action", 3, "placeholder", "value", "valueChange", "selectionChange"], [3, "value", 4, "ngFor", "ngForOf"], [1, "form-group"], [1, "icon_box", "p-1"], [3, "src", 4, "ngIf"], ["class", "btn btn-icon btn-light-danger btn-sm m-2", 3, "click", 4, "ngIf"], [1, "btn", "btn-secondary", "mr-2", 3, "click"], [1, "col-sm-4", "text-center"], [1, "btn", "btn-light-success", "font-weight-bold", "m-2", 3, "click"], [1, "btn", "btn-light-dark", "font-weight-bold", "m-2", 3, "click"], [1, "text-danger"], ["type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], [3, "value"], [3, "src"], [1, "btn", "btn-icon", "btn-light-danger", "btn-sm", "m-2", 3, "click"], [1, "flaticon2-trash"]],
        template: function ApplicationMenuComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ApplicationMenuComponent_ng_container_2_Template, 3, 0, "ng-container", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "async");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "h3", 4);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "translate");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 6);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, ApplicationMenuComponent_span_13_Template, 3, 3, "span", 7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 8);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_Template_button_click_14_listener() {
              return ctx.save();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](16, "translate");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "button", 9);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_Template_button_click_17_listener() {
              return ctx.cancel();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](19, "translate");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 10);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 11);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 12);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "i", 13);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 14);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](26, "translate");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 15);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "button", 16);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationMenuComponent_Template_button_click_28_listener() {
              return ctx.addItem();
            });

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "i", 17);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](31, "translate");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](32, ApplicationMenuComponent_div_32_Template, 3, 2, "div", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 9, ctx.isLoading$));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 11, "CONSTRUCTOR.APP_MENU.TITLE"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 13, "CONSTRUCTOR.APP_MENU.TITLE_TEXT"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.was_changed);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](16, 15, "GENERAL.LANGUAGES.SAVE_CHANGES"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](19, 17, "GENERAL.LANGUAGES.CANCEL"));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](26, 19, "CONSTRUCTOR.APP_MENU.TITLE_TEXT_FULL"), " ");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](31, 21, "CONSTRUCTOR.APP_MENU.ADD"), "");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.was_loaded);
          }
        },
        directives: [_angular_common__WEBPACK_IMPORTED_MODULE_14__["NgIf"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__["CdkDropList"], _angular_common__WEBPACK_IMPORTED_MODULE_14__["NgForOf"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__["CdkDrag"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__["CdkDragHandle"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_2__["CdkDragPlaceholder"], ng_inline_svg__WEBPACK_IMPORTED_MODULE_15__["InlineSVGDirective"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_16__["MatFormField"], _angular_material_select__WEBPACK_IMPORTED_MODULE_17__["MatSelect"], _angular_forms__WEBPACK_IMPORTED_MODULE_18__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_18__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_18__["NgModel"], _angular_material_core__WEBPACK_IMPORTED_MODULE_19__["MatOption"]],
        pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_14__["AsyncPipe"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__["TranslatePipe"]],
        styles: [".menu-list[_ngcontent-%COMP%] {\n  width: 500px;\n  max-width: 100%;\n  border: solid 1px #ccc;\n  min-height: 60px;\n  display: block;\n  background: white;\n  border-radius: 4px;\n  overflow: hidden;\n}\n\n.menu_item[_ngcontent-%COMP%] {\n  border: 1px solid #999;\n}\n\n.menu-box[_ngcontent-%COMP%] {\n  padding: 5px 5px;\n  color: rgba(0, 0, 0, 0.87);\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: space-between;\n  box-sizing: border-box;\n  cursor: move;\n  background: white;\n  font-size: 14px;\n}\n\n.cdk-drag-preview[_ngcontent-%COMP%] {\n  box-sizing: border-box;\n  border-radius: 4px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n}\n\n.cdk-drag-animating[_ngcontent-%COMP%] {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.menu-box[_ngcontent-%COMP%]:last-child {\n  border: none;\n}\n\n.menu-list.cdk-drop-list-dragging[_ngcontent-%COMP%]   .menu-box[_ngcontent-%COMP%]:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.menu-custom-placeholder[_ngcontent-%COMP%] {\n  background: #ccc;\n  border: dotted 3px #999;\n  min-height: 60px;\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.icon_box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  max-width: 50px;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxhcHBsaWNhdGlvbi1tZW51LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVFO0VBQ0ksc0JBQUE7QUFDTjs7QUFFRTtFQUNFLGdCQUFBO0VBRUEsMEJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FBQUo7O0FBR0U7RUFDRSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUhBQUE7QUFBSjs7QUFLRTtFQUNFLHNEQUFBO0FBRko7O0FBS0U7RUFDRSxZQUFBO0FBRko7O0FBS0U7RUFDRSxzREFBQTtBQUZKOztBQUtFO0VBQ0UsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0RBQUE7QUFGSjs7QUFNSTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBSE4iLCJmaWxlIjoiYXBwbGljYXRpb24tbWVudS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZW51LWxpc3Qge1xyXG4gICAgd2lkdGg6IDUwMHB4O1xyXG4gICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI2NjYztcclxuICAgIG1pbi1oZWlnaHQ6IDYwcHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICB9XHJcbiAgXHJcbiAgLm1lbnVfaXRlbSB7XHJcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OTk7XHJcbiAgfVxyXG5cclxuICAubWVudS1ib3gge1xyXG4gICAgcGFkZGluZzogNXB4IDVweDtcclxuICAgIFxyXG4gICAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC44Nyk7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgY3Vyc29yOiBtb3ZlO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5jZGstZHJhZy1wcmV2aWV3IHtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDVweCA1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMiksXHJcbiAgICAgICAgICAgICAgICAwIDhweCAxMHB4IDFweCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxyXG4gICAgICAgICAgICAgICAgMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxuICB9XHJcbiAgXHJcbiAgLmNkay1kcmFnLWFuaW1hdGluZyB7XHJcbiAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XHJcbiAgfVxyXG4gIFxyXG4gIC5tZW51LWJveDpsYXN0LWNoaWxkIHtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICB9XHJcbiAgXHJcbiAgLm1lbnUtbGlzdC5jZGstZHJvcC1saXN0LWRyYWdnaW5nIC5tZW51LWJveDpub3QoLmNkay1kcmFnLXBsYWNlaG9sZGVyKSB7XHJcbiAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XHJcbiAgfVxyXG4gIFxyXG4gIC5tZW51LWN1c3RvbS1wbGFjZWhvbGRlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjY2NjO1xyXG4gICAgYm9yZGVyOiBkb3R0ZWQgM3B4ICM5OTk7XHJcbiAgICBtaW4taGVpZ2h0OiA2MHB4O1xyXG4gICAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xyXG4gIH1cclxuXHJcbiAgLmljb25fYm94IHtcclxuICAgIGltZyB7XHJcbiAgICAgIG1heC13aWR0aDogNTBweDtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbiAgfSJdfQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ApplicationMenuComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-application-menu',
            templateUrl: './application-menu.component.html',
            styleUrls: ['./application-menu.component.scss']
          }]
        }], function () {
          return [{
            type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"]
          }, {
            type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModal"]
          }, {
            type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_3__["MatDialog"]
          }, {
            type: _ConstructorComponents_gallery_dialog_services_gallery_images_service__WEBPACK_IMPORTED_MODULE_9__["GalleryImagesService"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]
          }, {
            type: _services_translation_service__WEBPACK_IMPORTED_MODULE_10__["TranslationService"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
          }, {
            type: _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_11__["ToastService"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"]
          }, {
            type: _ConstructorComponents_subheader_services_subheader_service__WEBPACK_IMPORTED_MODULE_12__["SubheaderService"]
          }, {
            type: _services_application_service__WEBPACK_IMPORTED_MODULE_13__["ApplicationService"]
          }];
        }, null);
      })();
      /***/

    }
  }]);
})();
//# sourceMappingURL=application-menu-application-menu-module-es5.js.map