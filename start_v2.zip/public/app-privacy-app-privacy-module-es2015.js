(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app-privacy-app-privacy-module"],{

/***/ "0cvZ":
/*!***************************************************!*\
  !*** ./src/app/app-privacy/app-privacy.module.ts ***!
  \***************************************************/
/*! exports provided: AppPrivacyModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppPrivacyModule", function() { return AppPrivacyModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _app_privacy_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-privacy.component */ "euN6");
/* harmony import */ var _app_privacy_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-privacy-routing.module */ "f6ZB");






class AppPrivacyModule {
}
AppPrivacyModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppPrivacyModule });
AppPrivacyModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppPrivacyModule_Factory(t) { return new (t || AppPrivacyModule)(); }, imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateModule"],
            _app_privacy_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppPrivacyRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppPrivacyModule, { declarations: [_app_privacy_component__WEBPACK_IMPORTED_MODULE_3__["AppPrivacyComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateModule"],
        _app_privacy_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppPrivacyRoutingModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppPrivacyModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [_app_privacy_component__WEBPACK_IMPORTED_MODULE_3__["AppPrivacyComponent"]],
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                    _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateModule"],
                    _app_privacy_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppPrivacyRoutingModule"]
                ]
            }]
    }], null, null); })();


/***/ }),

/***/ "euN6":
/*!******************************************************!*\
  !*** ./src/app/app-privacy/app-privacy.component.ts ***!
  \******************************************************/
/*! exports provided: AppPrivacyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppPrivacyComponent", function() { return AppPrivacyComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");






class AppPrivacyComponent {
    constructor(activateRoute, httpClient, changeDetectorRef, meta) {
        this.activateRoute = activateRoute;
        this.httpClient = httpClient;
        this.changeDetectorRef = changeDetectorRef;
        this.meta = meta;
        this.unique_string_id = '';
        this.privacyText = '';
        this.unique_string_id = activateRoute.snapshot.params['unique_string_id'];
    }
    ngOnInit() {
        this.meta.addTag({ name: 'robots', content: 'noindex' });
        document.getElementById('kt_body').style.background = 'white';
        this.httpClient.post(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].apiUrl + 'api/getPublicApplicationPrivacy', {
            unique_string_id: this.unique_string_id
        }).toPromise().then(response => {
            this.privacyText = response.privacy;
            this.changeDetectorRef.detectChanges();
        });
    }
}
AppPrivacyComponent.ɵfac = function AppPrivacyComponent_Factory(t) { return new (t || AppPrivacyComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["Meta"])); };
AppPrivacyComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppPrivacyComponent, selectors: [["app-privacy"]], decls: 2, vars: 1, consts: [["id", "container"], ["id", "privacy", 3, "innerHTML"]], template: function AppPrivacyComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", ctx.privacyText, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
    } }, styles: ["#container[_ngcontent-%COMP%] {\n  max-width: 732px;\n  margin: 0 auto;\n}\n\n#privacy[_ngcontent-%COMP%] {\n  margin: 21px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGFwcC1wcml2YWN5LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxZQUFBO0FBRUYiLCJmaWxlIjoiYXBwLXByaXZhY3kuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcclxuICBtYXgtd2lkdGg6IDczMnB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbiNwcml2YWN5IHtcclxuICBtYXJnaW46IDIxcHg7XHJcbn1cclxuIl19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppPrivacyComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-privacy',
                templateUrl: './app-privacy.component.html',
                styleUrls: ['./app-privacy.component.scss']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }, { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }, { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ChangeDetectorRef"] }, { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["Meta"] }]; }, null); })();


/***/ }),

/***/ "f6ZB":
/*!***********************************************************!*\
  !*** ./src/app/app-privacy/app-privacy-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: AppPrivacyRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppPrivacyRoutingModule", function() { return AppPrivacyRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _app_privacy_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-privacy.component */ "euN6");





const routes = [
    {
        path: '',
        component: _app_privacy_component__WEBPACK_IMPORTED_MODULE_2__["AppPrivacyComponent"],
    }
];
class AppPrivacyRoutingModule {
}
AppPrivacyRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppPrivacyRoutingModule });
AppPrivacyRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppPrivacyRoutingModule_Factory(t) { return new (t || AppPrivacyRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppPrivacyRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppPrivacyRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ })

}]);
//# sourceMappingURL=app-privacy-app-privacy-module-es2015.js.map