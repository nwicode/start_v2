(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["analytics-settings-analytics-settings-module"], {
    /***/
    "FNlI":
    /*!*************************************************************************************!*\
      !*** ./src/app/constructor/analytics-settings/analytics-settings-routing.module.ts ***!
      \*************************************************************************************/

    /*! exports provided: AnalyticsSettingsRoutingModule */

    /***/
    function FNlI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AnalyticsSettingsRoutingModule", function () {
        return AnalyticsSettingsRoutingModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _analytics_settings_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./analytics-settings.component */
      "lWmd");

      var routes = [{
        path: '',
        component: _analytics_settings_component__WEBPACK_IMPORTED_MODULE_2__["AnalyticsSettingsComponent"],
        children: []
      }];

      var AnalyticsSettingsRoutingModule = function AnalyticsSettingsRoutingModule() {
        _classCallCheck(this, AnalyticsSettingsRoutingModule);
      };

      AnalyticsSettingsRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: AnalyticsSettingsRoutingModule
      });
      AnalyticsSettingsRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function AnalyticsSettingsRoutingModule_Factory(t) {
          return new (t || AnalyticsSettingsRoutingModule)();
        },
        imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AnalyticsSettingsRoutingModule, {
          imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
          exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AnalyticsSettingsRoutingModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "S6Q+":
    /*!*****************************************************************************!*\
      !*** ./src/app/constructor/analytics-settings/analytics-settings.module.ts ***!
      \*****************************************************************************/

    /*! exports provided: AnalyticsSettingsModule */

    /***/
    function S6Q(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AnalyticsSettingsModule", function () {
        return AnalyticsSettingsModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _analytics_settings_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./analytics-settings-routing.module */
      "FNlI");
      /* harmony import */


      var _analytics_settings_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./analytics-settings.component */
      "lWmd");
      /* harmony import */


      var _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../platform/LayoutsComponents/CommonExtensions.module */
      "csDf");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");
      /* harmony import */


      var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/material/tabs */
      "wZkO");
      /* harmony import */


      var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/material/snack-bar */
      "dNgK");
      /* harmony import */


      var _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../platform/framework/core/services/toast.service */
      "wV1m");

      var AnalyticsSettingsModule = function AnalyticsSettingsModule() {
        _classCallCheck(this, AnalyticsSettingsModule);
      };

      AnalyticsSettingsModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: AnalyticsSettingsModule
      });
      AnalyticsSettingsModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function AnalyticsSettingsModule_Factory(t) {
          return new (t || AnalyticsSettingsModule)();
        },
        providers: [_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBar"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_10__["ToastService"]],
        imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_4__["CommonExtensions"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_8__["MatTabsModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _analytics_settings_routing_module__WEBPACK_IMPORTED_MODULE_2__["AnalyticsSettingsRoutingModule"]]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AnalyticsSettingsModule, {
          declarations: [_analytics_settings_component__WEBPACK_IMPORTED_MODULE_3__["AnalyticsSettingsComponent"]],
          imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_4__["CommonExtensions"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_8__["MatTabsModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _analytics_settings_routing_module__WEBPACK_IMPORTED_MODULE_2__["AnalyticsSettingsRoutingModule"]]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AnalyticsSettingsModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            providers: [_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBar"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_10__["ToastService"]],
            declarations: [_analytics_settings_component__WEBPACK_IMPORTED_MODULE_3__["AnalyticsSettingsComponent"]],
            imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _platform_LayoutsComponents_CommonExtensions_module__WEBPACK_IMPORTED_MODULE_4__["CommonExtensions"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_8__["MatTabsModule"], _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_9__["MatSnackBarModule"], _analytics_settings_routing_module__WEBPACK_IMPORTED_MODULE_2__["AnalyticsSettingsRoutingModule"]]
          }]
        }], null, null);
      })();
      /***/

    },

    /***/
    "lWmd":
    /*!********************************************************************************!*\
      !*** ./src/app/constructor/analytics-settings/analytics-settings.component.ts ***!
      \********************************************************************************/

    /*! exports provided: AnalyticsSettingsComponent */

    /***/
    function lWmd(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AnalyticsSettingsComponent", function () {
        return AnalyticsSettingsComponent;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _services_translation_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../../services/translation.service */
      "ty2H");
      /* harmony import */


      var _ConstructorComponents_subheader_services_subheader_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../ConstructorComponents/subheader/_services/subheader.service */
      "0dlt");
      /* harmony import */


      var _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../platform/framework/core/services/toast.service */
      "wV1m");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _services_application_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../services/application.service */
      "AQhQ");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      function AnalyticsSettingsComponent_ng_container_2_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 4);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "div", 5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
        }
      }

      function AnalyticsSettingsComponent_div_4_span_8_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 14);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, "GENERAL.LANGUAGES.FORM_NOT_FILL"));
        }
      }

      function AnalyticsSettingsComponent_div_4_Template(rf, ctx) {
        if (rf & 1) {
          var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 6);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 7);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "h3", 8);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Google Analytics");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 9);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, AnalyticsSettingsComponent_div_4_span_8_Template, 3, 3, "span", 11);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 12);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AnalyticsSettingsComponent_div_4_Template_button_click_9_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);

            var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r4.save();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AnalyticsSettingsComponent_div_4_Template_button_click_12_listener() {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);

            var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

            return ctx_r6.cancel();
          });

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](14, "translate");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 5, "CONSTRUCTOR.MIX_PANEL_SETTINGS.TITLE_TEXT"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.formGroup.invalid && ctx_r1.formGroup.touched);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx_r1.formGroup.invalid && ctx_r1.formGroup.touched);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 7, "GENERAL.LANGUAGES.SAVE_CHANGES"));

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](14, 9, "GENERAL.LANGUAGES.CANCEL"));
        }
      }

      function AnalyticsSettingsComponent_div_5_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 15);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 16);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 17);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "label");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Analytics View ID");

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "input", 18);

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }

        if (rf & 2) {
          var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();

          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx_r2.formGroup);
        }
      }

      var AnalyticsSettingsComponent = /*#__PURE__*/function () {
        function AnalyticsSettingsComponent(translationService, subheader, toastService, formBuilder, router, applicationService) {
          _classCallCheck(this, AnalyticsSettingsComponent);

          this.translationService = translationService;
          this.subheader = subheader;
          this.toastService = toastService;
          this.formBuilder = formBuilder;
          this.router = router;
          this.applicationService = applicationService;
        }

        _createClass(AnalyticsSettingsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.applicationId = Number(this.router.url.match(/constructor\/(\d+)/)[1]);
            setTimeout(function () {
              _this.subheader.setTitle('CONSTRUCTOR.GOOGLE_ANALYTICS_SETTINGS.TITLE');

              _this.subheader.setBreadcrumbs([{
                title: 'CONSTRUCTOR.GOOGLE_ANALYTICS_SETTINGS.TITLE',
                linkText: 'CONSTRUCTOR.GOOGLE_ANALYTICS_SETTINGS.TITLE',
                linkPath: '/constructor/' + _this.applicationId + '/analytics-settings'
              }]);
            }, 1);
            this.isLoading$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
              observer.next(true);

              _this.applicationService.getAnalyticsSettings(_this.applicationId).then(function (result) {
                _this.googleAnalyticsViewID = result.google_analytics_view_id;

                _this.initForm();

                observer.next(false);
              });
            });
          }
        }, {
          key: "initForm",
          value: function initForm() {
            this.formGroup = this.formBuilder.group({
              google_analytics_view_id: [this.googleAnalyticsViewID]
            });
          }
        }, {
          key: "save",
          value: function save() {
            var _this2 = this;

            this.formGroup.markAllAsTouched();

            if (!this.formGroup.valid) {
              return;
            }

            var formValues = this.formGroup.value;
            this.isLoading$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
              observer.next(true);

              _this2.formGroup.disable();

              _this2.applicationService.setAnalyticsSettings(_this2.applicationId, formValues.google_analytics_view_id).then(function (result) {
                if (result.is_error) {
                  _this2.toastService.showsToastBar(_this2.translationService.translatePhrase('GENERAL.LANGUAGES.CHANGES_NOT_SAVED'), 'danger');
                } else {
                  _this2.googleAnalyticsViewID = result.mixpanel_token;

                  _this2.toastService.showsToastBar(_this2.translationService.translatePhrase('GENERAL.LANGUAGES.CHANGES_SAVED'), 'success');
                }

                _this2.formGroup.enable();

                observer.next(false);
              });
            });
          }
        }, {
          key: "cancel",
          value: function cancel() {
            var _this3 = this;

            this.isLoading$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"](function (observer) {
              observer.next(true);

              _this3.initForm();

              observer.next(false);
            });
          }
        }]);

        return AnalyticsSettingsComponent;
      }();

      AnalyticsSettingsComponent.ɵfac = function AnalyticsSettingsComponent_Factory(t) {
        return new (t || AnalyticsSettingsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_translation_service__WEBPACK_IMPORTED_MODULE_2__["TranslationService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ConstructorComponents_subheader_services_subheader_service__WEBPACK_IMPORTED_MODULE_3__["SubheaderService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_application_service__WEBPACK_IMPORTED_MODULE_7__["ApplicationService"]));
      };

      AnalyticsSettingsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
        type: AnalyticsSettingsComponent,
        selectors: [["app-analytics-settings"]],
        decls: 6,
        vars: 5,
        consts: [[1, "card", "card-custom"], [4, "ngIf"], ["class", "card-header py-3", 4, "ngIf"], ["class", "form", 3, "formGroup", 4, "ngIf"], [1, "progress", "progress-modal"], ["role", "progressbar", "aria-valuenow", "100", "aria-valuemin", "0", "aria-valuemax", "100", 1, "progress-bar", "progress-bar-striped", "progress-bar-animated", "bg-primary", 2, "width", "100%"], [1, "card-header", "py-3"], [1, "card-title", "align-items-start", "flex-column"], [1, "card-label", "font-weight-bolder", "text-dark"], [1, "text-muted", "font-weight-bold", "font-size-sm", "mt-1"], [1, "card-toolbar"], ["class", "label label-danger label-pill label-inline mr-2", 4, "ngIf"], ["type", "submit", 1, "btn", "btn-success", "mr-2", 3, "disabled", "click"], ["type", "reset", 1, "btn", "btn-secondary", 3, "click"], [1, "label", "label-danger", "label-pill", "label-inline", "mr-2"], [1, "form", 3, "formGroup"], [1, "card-body"], [1, "form-group"], ["type", "text", "name", "google_analytics_view_id", "formControlName", "google_analytics_view_id", 1, "form-control", "form-control-solid"]],
        template: function AnalyticsSettingsComponent_Template(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, AnalyticsSettingsComponent_ng_container_2_Template, 3, 0, "ng-container", 1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "async");

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, AnalyticsSettingsComponent_div_4_Template, 15, 11, "div", 2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, AnalyticsSettingsComponent_div_5_Template, 6, 1, "div", 3);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
          }

          if (rf & 2) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 3, ctx.isLoading$));

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.formGroup);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);

            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.formGroup);
          }
        },
        directives: [_angular_common__WEBPACK_IMPORTED_MODULE_8__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroupDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControlName"]],
        pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_8__["AsyncPipe"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslatePipe"]],
        styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbmFseXRpY3Mtc2V0dGluZ3MuY29tcG9uZW50LnNjc3MifQ== */"]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AnalyticsSettingsComponent, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
          args: [{
            selector: 'app-analytics-settings',
            templateUrl: './analytics-settings.component.html',
            styleUrls: ['./analytics-settings.component.scss']
          }]
        }], function () {
          return [{
            type: _services_translation_service__WEBPACK_IMPORTED_MODULE_2__["TranslationService"]
          }, {
            type: _ConstructorComponents_subheader_services_subheader_service__WEBPACK_IMPORTED_MODULE_3__["SubheaderService"]
          }, {
            type: _platform_framework_core_services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"]
          }, {
            type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
          }, {
            type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
          }, {
            type: _services_application_service__WEBPACK_IMPORTED_MODULE_7__["ApplicationService"]
          }];
        }, null);
      })();
      /***/

    }
  }]);
})();
//# sourceMappingURL=analytics-settings-analytics-settings-module-es5.js.map