/**
* language settings file
* (this file automaticly generated from backed in production mode)
*/
export const laguageSettings = {"default":"ru","languages":[{"id":1,"code":"en","name":"ENGLISH","file":"","image":"assets\/languages\/en.png","is_default":0},{"id":2,"code":"ru","name":"RUSSIAN","file":"","image":"assets\/languages\/ru.png","is_default":1}]}