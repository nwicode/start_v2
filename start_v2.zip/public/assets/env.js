(function(window) {
    window["env"] = window["env"] || {};
    window["env"]["domainName"] = "127.0.0.1:8000";
    window["env"]["debug"] = true;
})(this);