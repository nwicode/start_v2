(function (window) {
    window['env'] = window['env'] || {};
    window['env']['domainName'] = '${DOMAIN_NAME}';
    window['env']['debug'] = '${DEBUG}';
})(this);
