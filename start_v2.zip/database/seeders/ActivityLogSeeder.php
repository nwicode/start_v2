<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ActivityLogSeeder extends Seeder {
    
    public function run() {
        
        /*DB::table('activity_logs')->insert([
            'user_id'=> 1,
            'app_id'=> 0,
            'name'=> 'Test log',
            'text'=> 'Тестовая активность'
        ]);*/

    }
}